# -*- coding: utf-8 -*-
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
"""Inference-time sensitivity sweep for MaskResModel AFHS parameters.

Replicates model.forward exactly (see model.py) with the highlight gain
exposed as a variable. Loads the trained runs/full checkpoint, overrides one
parameter at a time, and evaluates EN/SD/SF/SSIM_VIS/SSIM_IR/MI on the TNO
(54 pairs) and RoadScene (40 pairs) test manifests with the exact pipeline of
eval_fusion.py + metrics.py.

Usage:
  python sens_sweep.py --param tau   --dataset tno
  python sens_sweep.py --param gain  --dataset road
  python sens_sweep.py --param base  --dataset tno     # trained baseline
"""
import argparse
import csv
import math
import os
import sys

import cv2
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from maskresmodel.model import MaskResModel            # noqa: E402
from maskresmodel.metrics import calculate_fusion_metrics  # noqa: E402
from maskresmodel.imgio import imread_gray, imread_rgb     # noqa: E402

ROOT = r"C:\Users\zcwan\Desktop\多模态\IRVIS_Fusion_SCI"
CKPT = os.path.join(ROOT, "runs", "full", "checkpoints", "model_best.pth")
MANIFESTS = {
    "tno": os.path.join(ROOT, "data", "tno.csv"),
    "road": os.path.join(ROOT, "data", "roadscene_test.csv"),
}
IMG_SIZE = (256, 256)
OUT_CSV = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       "sens_results.csv")

# sweep grids (trained values are filled in after loading the checkpoint)
TAU_GRID = [0.85, 0.875, None, 0.91, 0.925]      # None -> trained
GAIN_GRID = [10.0, 15.0, None, 30.0, 40.0]       # None -> trained (20)
WR_GRID = [0.35, 0.45, None, 0.60, 0.70]         # None -> trained sigma(res_w)
WIR_GRID = [0.40, 0.47, None, 0.62, 0.72]        # None -> trained sigma(ir_w)


def logit(p):
    return math.log(p / (1.0 - p))


def fuse(model, ir, vis, gain):
    mask = torch.tanh(model.mask_net(ir)) * 0.45 + 0.5
    res = model.res_net.layer(torch.cat([vis, mask], dim=1)) * mask
    res = torch.tanh(res) * torch.sigmoid(model.res_w)
    base = vis + res
    ir_rgb = ir.repeat(1, 3, 1, 1)
    irw = torch.sigmoid(model.ir_w)
    base = base * (1 - mask * irw) + ir_rgb * (mask * irw)
    vis_gray = vis.mean(dim=1, keepdim=True)
    tau = torch.sigmoid(model.theta) * 0.2 + 0.75
    h = torch.sigmoid((vis_gray - tau) * gain)
    return torch.clamp(base * (1 - h) + ir_rgb * h, 0, 1)


def preprocess(ir_path, vis_path):
    ir = imread_gray(ir_path)
    vis = imread_rgb(vis_path)
    ir = cv2.resize(ir, IMG_SIZE)
    vis = cv2.resize(vis, IMG_SIZE)
    ir_t = torch.from_numpy((ir / 255.0).astype(np.float32)).unsqueeze(0).unsqueeze(0)
    vis_t = torch.from_numpy((vis / 255.0).astype(np.float32)).permute(2, 0, 1).unsqueeze(0)
    return ir_t, vis_t, ir, vis


def evaluate(model, gain, manifest):
    rows = list(csv.DictReader(open(manifest, encoding="utf-8")))
    res = []
    with torch.no_grad():
        for r in rows:
            ir_t, vis_t, ir_raw, vis_raw = preprocess(r["ir_path"], r["vis_path"])
            fused = fuse(model, ir_t, vis_t, gain)
            f_np = fused.squeeze(0).permute(1, 2, 0).cpu().numpy()
            f_u8 = (np.clip(f_np, 0, 1) * 255).astype(np.uint8)
            vis_rgb = cv2.resize(imread_rgb(r["vis_path"]), IMG_SIZE)
            ir_ori = cv2.resize(imread_gray(r["ir_path"]), IMG_SIZE)
            res.append(calculate_fusion_metrics(f_u8, vis_rgb, ir_ori))
    keys = ["EN", "SD", "SF", "SSIM_VIS", "SSIM_IR", "MI"]
    return {k: round(float(np.mean([x[k] for x in res])), 4) for k in keys}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--param", required=True,
                    choices=["tau", "gain", "wr", "wir", "base"])
    ap.add_argument("--dataset", required=True, choices=["tno", "road"])
    args = ap.parse_args()

    torch.set_num_threads(12)

    model = MaskResModel("full")
    sd = torch.load(CKPT, map_location="cpu")
    model.load_state_dict(sd)
    model.eval()

    wr0 = float(torch.sigmoid(model.res_w))
    wir0 = float(torch.sigmoid(model.ir_w))
    tau0 = float(torch.sigmoid(model.theta)) * 0.2 + 0.75
    print(f"[sens] trained: sigma(w_r)={wr0:.4f} sigma(w_ir)={wir0:.4f} "
          f"tau={tau0:.4f} (gain=20)")
    theta0 = float(model.theta)

    if args.param == "tau":
        grid = [(v if v is not None else tau0, v is None) for v in TAU_GRID]
    elif args.param == "gain":
        grid = [(v if v is not None else 20.0, v is None) for v in GAIN_GRID]
    elif args.param == "wr":
        grid = [(v if v is not None else wr0, v is None) for v in WR_GRID]
    elif args.param == "wir":
        grid = [(v if v is not None else wir0, v is None) for v in WIR_GRID]
    else:
        grid = [(0.0, True)]

    manifest = MANIFESTS[args.dataset]
    write_header = not os.path.exists(OUT_CSV)
    with open(OUT_CSV, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if write_header:
            w.writerow(["param", "value", "trained", "dataset",
                        "EN", "SD", "SF", "SSIM_VIS", "SSIM_IR", "MI"])
        for val, is_trained in grid:
            with torch.no_grad():
                model.res_w.data.fill_(logit(wr0))
                model.ir_w.data.fill_(logit(wir0))
                model.theta.data.fill_(theta0)
            gain = 20.0
            applied = val
            if args.param == "tau":
                model.theta.data.fill_(logit((val - 0.75) / 0.2))
            elif args.param == "gain":
                gain = val
            elif args.param == "wr":
                model.res_w.data.fill_(logit(val))
            elif args.param == "wir":
                model.ir_w.data.fill_(logit(val))
            means = evaluate(model, gain, manifest)
            w.writerow([args.param, applied, int(is_trained), args.dataset,
                        means["EN"], means["SD"], means["SF"],
                        means["SSIM_VIS"], means["SSIM_IR"], means["MI"]])
            f.flush()
            print(f"[sens] {args.param}={val} trained={is_trained} "
                  f"{args.dataset}: {means}")


if __name__ == "__main__":
    main()
