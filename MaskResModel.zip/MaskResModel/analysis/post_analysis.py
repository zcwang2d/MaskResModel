# -*- coding: utf-8 -*-
"""
post_analysis.py — compute AG for ALL methods (baselines + proposed variants),
merge with eval summaries, and write unified metric tables per dataset.

All numbers are computed locally from the fused outputs produced on this machine.
"""
import csv
import json
import os

import cv2
import numpy as np
from PIL import Image

ROOT = r"C:\Users\zcwan\Desktop\多模态\IRVIS_Fusion_SCI"
BASELINES = os.path.join(ROOT, "baselines")
PROPOSED = os.path.join(ROOT, "results", "proposed")
METRICS = os.path.join(ROOT, "metrics")

BASELINE_METHODS = ["DWT", "GTF", "DenseFuse", "RFN_Nest", "FusionGAN", "TarDAL"]
VARIANTS = ["full", "no_afhs", "no_rcm", "no_ltsm", "no_multi"]
DATASETS = ["tno", "roadscene_test"]


def average_gradient(img_u8):
    """AG = mean over pixels of sqrt((dx^2+dy^2)/2), central differences on gray."""
    if img_u8.ndim == 3:
        g = cv2.cvtColor(img_u8, cv2.COLOR_RGB2GRAY)
    else:
        g = img_u8
    g = g.astype(np.float32)
    dx = cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3)
    dy = cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3)
    return float(np.mean(np.sqrt((dx ** 2 + dy ** 2) / 2.0)))


def read_fused(path):
    return np.asarray(Image.open(path))


def list_fused(folder):
    out = {}
    for fn in os.listdir(folder):
        if fn.endswith(".png") and not fn.endswith("_mask.png") and not fn.endswith("_res.png"):
            out[os.path.splitext(fn)[0]] = os.path.join(folder, fn)
    return out


def load_csv_summary(path):
    with open(path, encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    return rows


def main():
    # 1) baseline metrics (EN/SD/SF/SSIM/MI) from baselines_summary.json
    with open(os.path.join(METRICS, "baselines_summary.json"), encoding="utf-8") as f:
        base_sum = json.load(f)["methods"]

    # 2) proposed metrics from each eval summary.json
    prop_sum = {}
    for v in VARIANTS:
        for d in DATASETS:
            sp = os.path.join(PROPOSED, v, d, "summary.json")
            with open(sp, encoding="utf-8") as f:
                prop_sum[(v, d)] = json.load(f)

    # 3) compute AG from fused outputs
    all_rows = {}
    for d in DATASETS:
        rows = []
        for m in BASELINE_METHODS:
            folder = os.path.join(BASELINES, m, d, "fused")
            files = list_fused(folder)
            ags = [average_gradient(read_fused(p)) for p in files.values()]
            met = base_sum[m]["metrics"][d]
            row = {"method": m, "dataset": d,
                   "EN": met["EN"], "SD": met["SD"], "SF": met["SF"],
                   "AG": round(float(np.mean(ags)), 4),
                   "SSIM_VIS": met["SSIM_VIS"], "SSIM_IR": met["SSIM_IR"],
                   "MI": met["MI"]}
            rows.append(row)
        for v in VARIANTS:
            folder = os.path.join(PROPOSED, v, d, "fused")
            files = list_fused(folder)
            ags = [average_gradient(read_fused(p)) for p in files.values()]
            m = prop_sum[(v, d)]["means"]
            row = {"method": f"Ours-{v}", "dataset": d,
                   "EN": m["EN"], "SD": m["SD"], "SF": m["SF"],
                   "AG": round(float(np.mean(ags)), 4),
                   "SSIM_VIS": m["SSIM_VIS"], "SSIM_IR": m["SSIM_IR"],
                   "MI": m["MI"]}
            rows.append(row)
        all_rows[d] = rows

        out_csv = os.path.join(METRICS, f"all_metrics_{d}.csv")
        with open(out_csv, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        print(f"[post] wrote {out_csv}")
        for r in rows:
            print(f"  {r['method']:16s} EN {r['EN']:.4f} SD {r['SD']:.4f} SF {r['SF']:.4f} "
                  f"AG {r['AG']:.4f} S_V {r['SSIM_VIS']:.4f} S_I {r['SSIM_IR']:.4f} MI {r['MI']:.4f}")

    with open(os.path.join(METRICS, "all_metrics.json"), "w", encoding="utf-8") as f:
        json.dump(all_rows, f, indent=2, ensure_ascii=False)
    print("[post] ALL_DONE")


if __name__ == "__main__":
    main()
