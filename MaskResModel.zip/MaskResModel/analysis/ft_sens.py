# -*- coding: utf-8 -*-
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
"""Warm-start fine-tuning sensitivity of the loss weights.

Starts from the trained runs/full model and fine-tunes for TOTAL_EPOCHS epochs
with a perturbed loss-weight setting, recording per-epoch TNO test metrics to
show metric drift. A control run re-fine-tunes with the original weights.

Chunked execution (300 s per call):
  python ft_sens.py --variant res_half --epochs-per-call 3
  ... repeat until 12 epochs done ...
  python ft_sens.py --variant res_half --eval
"""
import argparse
import csv
import json
import os
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import CosineAnnealingLR

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from maskresmodel.model import MaskResModel              # noqa: E402
from maskresmodel.dataset import IRVISDataset            # noqa: E402
from maskresmodel.metrics import calculate_fusion_metrics  # noqa: E402
from maskresmodel.imgio import imread_gray, imread_rgb   # noqa: E402
from pipeline.eval_fusion import preprocess          # noqa: E402

ROOT = r"C:\Users\zcwan\Desktop\多模态\IRVIS_Fusion_SCI"
CKPT = os.path.join(ROOT, "runs", "full", "checkpoints", "model_best.pth")
TRAIN_CSV = os.path.join(ROOT, "data", "train_256_manifest.csv")
TEST_CSV = {
    "tno": os.path.join(ROOT, "data", "tno.csv"),
    "road": os.path.join(ROOT, "data", "roadscene_test.csv"),
}
OUT_ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ft_runs")
TOTAL_EPOCHS = 6

VARIANTS = {
    "control":    (1.0, 0.4, 0.6, 0.01, 0.005),
    "res_half":   (1.0, 0.2, 0.6, 0.01, 0.005),
    "res_double": (1.0, 0.8, 0.6, 0.01, 0.005),
    "bg_half":    (1.0, 0.4, 0.3, 0.01, 0.005),
    "bg_double":  (1.0, 0.4, 1.2, 0.01, 0.005),
    "mask_half":  (0.5, 0.4, 0.6, 0.01, 0.005),
}


def weighted_loss(ir, vis, mask, res, fused, w):
    w_mask, w_res, w_bg, w_range, w_reg = w
    ir_norm = (ir - ir.min()) / (ir.max() - ir.min() + 1e-8)
    l_mask = torch.mean(torch.abs(mask - ir_norm))
    l_res = torch.mean(torch.abs(res * mask - mask * 0.2))
    mask_3ch = mask.repeat(1, 3, 1, 1)
    l_bg = torch.mean(torch.abs(fused * (1 - mask_3ch) - vis * (1 - mask_3ch)))
    l_range = torch.mean(torch.relu(-fused)) + torch.mean(torch.relu(fused - 1.0))
    l_reg = torch.mean(torch.abs(res))
    total = (w_mask * l_mask + w_res * l_res + w_bg * l_bg
             + w_range * l_range + w_reg * l_reg)
    return total, l_mask, l_res, l_bg


def eval_test(model, dataset):
    import cv2
    rows = list(csv.DictReader(open(TEST_CSV[dataset], encoding="utf-8")))
    res = []
    with torch.no_grad():
        for r in rows:
            ir_t, vis_t = preprocess(r["ir_path"], r["vis_path"])
            fused, _, _ = model(ir_t, vis_t)
            f_u8 = (np.clip(fused.squeeze(0).permute(1, 2, 0).numpy(), 0, 1) * 255).astype(np.uint8)
            vis_rgb = cv2.resize(imread_rgb(r["vis_path"]), (256, 256))
            ir_ori = cv2.resize(imread_gray(r["ir_path"]), (256, 256))
            res.append(calculate_fusion_metrics(f_u8, vis_rgb, ir_ori))
    keys = ["EN", "SD", "SF", "SSIM_VIS", "SSIM_IR", "MI"]
    return {k: round(float(np.mean([x[k] for x in res])), 4) for k in keys}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--variant", required=True, choices=list(VARIANTS) + ["all"])
    ap.add_argument("--epochs-per-call", type=int, default=3)
    ap.add_argument("--eval", action="store_true")
    ap.add_argument("--threads", type=int, default=12)
    ap.add_argument("--skip-eval", action="store_true")
    args = ap.parse_args()

    torch.set_num_threads(args.threads)
    variants = list(VARIANTS) if args.variant == "all" else [args.variant]

    for var in variants:
        out = os.path.join(OUT_ROOT, var)
        os.makedirs(out, exist_ok=True)
        state_p = os.path.join(out, "state.json")
        start_epoch = 0
        if os.path.exists(state_p):
            start_epoch = json.load(open(state_p))["epoch"] + 1

        if args.eval:
            model = MaskResModel("full")
            model.load_state_dict(torch.load(os.path.join(out, "model_last.pth"),
                                             map_location="cpu"))
            model.eval()
            rec = {"variant": var, "weights": VARIANTS[var], "epochs_done": start_epoch}
            for ds in ("tno", "road"):
                rec[ds] = eval_test(model, ds)
            rec["sigma_wr"] = round(float(torch.sigmoid(model.res_w)), 4)
            rec["sigma_wir"] = round(float(torch.sigmoid(model.ir_w)), 4)
            rec["tau"] = round(float(torch.sigmoid(model.theta)) * 0.2 + 0.75, 4)
            fp = os.path.join(OUT_ROOT, "ft_final.csv")
            hdr = not os.path.exists(fp)
            with open(fp, "a", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=list(rec.keys()))
                if hdr:
                    w.writeheader()
                w.writerow(rec)
            print(f"[ft] {var} eval: {rec}")
            continue

        if start_epoch >= TOTAL_EPOCHS:
            print(f"[ft] {var} already done ({TOTAL_EPOCHS} epochs)")
            continue

        model = MaskResModel("full")
        model.load_state_dict(torch.load(CKPT, map_location="cpu"))
        opt_p = os.path.join(out, "opt_last.pt")
        if os.path.exists(opt_p):
            # resume: model last + optimizer state
            model.load_state_dict(torch.load(os.path.join(out, "model_last.pth"),
                                             map_location="cpu"))
        model.train()
        optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)
        scheduler = CosineAnnealingLR(optimizer, T_max=TOTAL_EPOCHS, eta_min=1e-6)
        if os.path.exists(opt_p):
            st = torch.load(opt_p, map_location="cpu")
            optimizer.load_state_dict(st["opt"])
            scheduler.load_state_dict(st["sch"])

        loader = DataLoader(IRVISDataset(TRAIN_CSV, augment=True),
                            batch_size=10, shuffle=True, num_workers=0)
        w = VARIANTS[var]
        logf = open(os.path.join(out, "log.jsonl"), "a", encoding="utf-8")
        end = min(start_epoch + args.epochs_per_call, TOTAL_EPOCHS)
        for epoch in range(start_epoch, end):
            t0 = time.time()
            model.train()
            tot, lm, lr_, lb = 0.0, 0.0, 0.0, 0.0
            for ir, vis in loader:
                fused, mask, res = model(ir, vis)
                loss, a, b, c = weighted_loss(ir, vis, mask, res, fused, w)
                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 0.5)
                optimizer.step()
                tot += loss.item(); lm += a.item(); lr_ += b.item(); lb += c.item()
            scheduler.step()
            n = len(loader)
            if args.skip_eval:
                rec = {"epoch": epoch, "loss": round(tot / n, 5),
                       "mask": round(lm / n, 5), "res": round(lr_ / n, 5),
                       "bg": round(lb / n, 5)}
            else:
                model.eval()
                m_tno = eval_test(model, "tno")
                rec = {"epoch": epoch, "loss": round(tot / n, 5),
                       "mask": round(lm / n, 5), "res": round(lr_ / n, 5),
                       "bg": round(lb / n, 5), **m_tno}
            logf.write(json.dumps(rec) + "\n"); logf.flush()
            print(f"[ft] {var} ep {epoch} loss {rec['loss']:.4f} "
                  + ("" if args.skip_eval else
                     f"EN {m_tno['EN']} SD {m_tno['SD']} MI {m_tno['MI']} ")
                  + f"({time.time()-t0:.0f}s)")
            torch.save(model.state_dict(), os.path.join(out, "model_last.pth"))
            torch.save({"opt": optimizer.state_dict(), "sch": scheduler.state_dict()},
                       opt_p)
            with open(state_p, "w") as f:
                json.dump({"epoch": epoch}, f)
        logf.close()


if __name__ == "__main__":
    main()
