# -*- coding: utf-8 -*-
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
"""Term-wise loss analysis on the test sets with the trained model.

Reports the raw magnitude of every loss term and its weighted contribution,
to justify the loss weights (1.0, 0.4, 0.6, 0.01, 0.005) as gradient-balancing.
Also reports the converged AFHS scalars.
"""
import csv
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from maskresmodel.model import MaskResModel   # noqa: E402
from maskresmodel.loss import MaskResLoss     # noqa: E402
from pipeline.eval_fusion import preprocess  # noqa: E402

ROOT = r"C:\Users\zcwan\Desktop\多模态\IRVIS_Fusion_SCI"
CKPT = os.path.join(ROOT, "runs", "full", "checkpoints", "model_best.pth")
MANIFESTS = {
    "tno": os.path.join(ROOT, "data", "tno.csv"),
    "road": os.path.join(ROOT, "data", "roadscene_test.csv"),
}

torch.set_num_threads(12)
model = MaskResModel("full")
model.load_state_dict(torch.load(CKPT, map_location="cpu"))
model.eval()
crit = MaskResLoss("full")

print("converged: sigma(w_r)=%.4f sigma(w_ir)=%.4f tau=%.4f" % (
    torch.sigmoid(model.res_w), torch.sigmoid(model.ir_w),
    torch.sigmoid(model.theta) * 0.2 + 0.75))

for name, manifest in MANIFESTS.items():
    rows = list(csv.DictReader(open(manifest, encoding="utf-8")))
    sums = np.zeros(5)
    with torch.no_grad():
        for r in rows:
            ir_t, vis_t = preprocess(r["ir_path"], r["vis_path"])
            fused, mask, res = model(ir_t, vis_t)
            total, l_mask, l_res, l_bg, l_range, l_reg = crit(ir_t, vis_t, mask, res, fused)
            sums += [l_mask, l_res, l_bg, l_range, l_reg]
    n = len(rows)
    mask_, res_, bg_, range_, reg_ = sums / n
    total = mask_ + 0.4 * res_ + 0.6 * bg_ + 0.01 * range_ + 0.005 * reg_
    print(f"\n[{name}] n={n}  (raw term mean | weighted contribution)")
    print(f"  L_mask  w=1.0   raw={mask_:.4f}  weighted={1.0*mask_:.4f} ({1.0*mask_/total*100:.1f}%)")
    print(f"  L_res   w=0.4   raw={res_:.4f}  weighted={0.4*res_:.4f} ({0.4*res_/total*100:.1f}%)")
    print(f"  L_bg    w=0.6   raw={bg_:.4f}  weighted={0.6*bg_:.4f} ({0.6*bg_/total*100:.1f}%)")
    print(f"  L_range w=0.01  raw={range_:.4f}  weighted={0.01*range_:.4f} ({0.01*range_/total*100:.1f}%)")
    print(f"  L_reg   w=0.005 raw={reg_:.4f}  weighted={0.005*reg_:.4f} ({0.005*reg_/total*100:.1f}%)")
    print(f"  total(avg per pair)={total:.4f}")
