# -*- coding: utf-8 -*-
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
"""END-TO-END audit: recompute every metric in Tables 1 & 2 directly from the
fused output PNGs (all 7 methods x 94 pairs) and compare with the manuscript.

Usage: python audit_tables.py tno|road
"""
import csv
import os
import sys

import cv2
import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from maskresmodel.metrics import calculate_fusion_metrics  # noqa: E402
from maskresmodel.imgio import imread_gray, imread_rgb      # noqa: E402

ROOT = r"C:\Users\zcwan\Desktop\多模态\IRVIS_Fusion_SCI"
DOCX = r'C:\Users\zcwan\Desktop\多模态\image20261008\01_Manuscript_MaskResModel.docx'
DS = sys.argv[1]  # tno | road
MANIFEST = os.path.join(ROOT, "data", "tno.csv" if DS == "tno" else "roadscene_test.csv")

METHOD_DIR = {
    "DWT": os.path.join(ROOT, "baselines", "DWT"),
    "GTF": os.path.join(ROOT, "baselines", "GTF"),
    "DenseFuse": os.path.join(ROOT, "baselines", "DenseFuse"),
    "RFN-Nest": os.path.join(ROOT, "baselines", "RFN_Nest"),
    "FusionGAN": os.path.join(ROOT, "baselines", "FusionGAN"),
    "TarDAL": os.path.join(ROOT, "baselines", "TarDAL"),
    "Ours": os.path.join(ROOT, "results", "proposed", "full"),
}
METRICS = ["EN", "SD", "SF", "AG", "SSIM_VIS", "SSIM_IR", "MI"]

# ---- read paper tables from the docx ----
from docx import Document  # noqa: E402
doc = Document(DOCX)
paper = {}
for tbl in doc.tables:
    hdr = [c.text.strip() for c in tbl.rows[0].cells]
    if hdr[:2] == ["Method", "EN"] and "MI" in hdr:
        # Single merged Table 1 (2026-10-14): TNO rows, separator row,
        # then RoadScene rows.
        cur = "tno"
        for row in tbl.rows[1:]:
            vals = [c.text.strip() for c in row.cells]
            if vals[0].startswith("RoadScene"):
                cur = "road"
                continue
            if vals[0]:
                paper.setdefault(cur, {})[vals[0]] = vals[1:]
        break

key = "tno" if DS == "tno" else "road"
DISK_DS = {"tno": "tno", "road": "roadscene_test"}[key]
print(f"[audit] paper {key} methods:", list(paper.get(key, {}).keys()))
rows = list(csv.DictReader(open(MANIFEST, encoding="utf-8")))
print(f"[audit] recomputing {len(rows)} pairs x {len(METHOD_DIR)} methods ...")

def avg_gradient(fg):
    """AG as originally computed: mean Sobel-gradient magnitude / sqrt(2)."""
    g = cv2.cvtColor(fg, cv2.COLOR_RGB2GRAY).astype(np.float64) \
        if fg.ndim == 3 else fg.astype(np.float64)
    sx = cv2.Sobel(g, cv2.CV_64F, 1, 0)
    sy = cv2.Sobel(g, cv2.CV_64F, 0, 1)
    return float(np.sqrt(sx ** 2 + sy ** 2).mean() / np.sqrt(2))


def pil_resize_u8(arr, size=(256, 256), resample=Image.BILINEAR):
    return np.asarray(Image.fromarray(arr).resize(size, resample))


results = {}
for method, base in METHOD_DIR.items():
    per = []
    for r in rows:
        fused = imread_rgb(os.path.join(base, DISK_DS, "fused", r["pair_id"] + ".png"))
        if method == "Ours":
            # Ours was evaluated by code/eval_fusion.py: cv2.resize references.
            vis = cv2.resize(imread_rgb(r["vis_path"]), (256, 256))
            ir = cv2.resize(imread_gray(r["ir_path"]), (256, 256))
        elif method == "TarDAL":
            # TarDAL was evaluated by code/eval_tardal.py: PIL default (BICUBIC).
            vis = pil_resize_u8(imread_rgb(r["vis_path"]), resample=Image.BICUBIC)
            ir = pil_resize_u8(imread_gray(r["ir_path"]), resample=Image.BICUBIC)
        else:
            # Baselines were evaluated by baselines_code/common.py: PIL BILINEAR.
            vis = pil_resize_u8(imread_rgb(r["vis_path"]))
            ir = pil_resize_u8(imread_gray(r["ir_path"]))
        m = calculate_fusion_metrics(fused, vis, ir)
        m["AG"] = avg_gradient(fused)
        per.append(m)
    results[method] = {m: round(float(np.mean([x[m] for x in per])), 4)
                       for m in METRICS}

print(f"\n==== {key.upper()} recomputed vs paper ====")
all_ok = True
for method, vals in results.items():
    prow = paper.get(key, {}).get(method)
    if prow is None:
        print(f"  !! paper row missing for {method}")
        all_ok = False
        continue
    pdict = dict(zip(METRICS, [float(x) for x in prow]))
    diffs = []
    for m in METRICS:
        d = abs(results[method][m] - pdict[m])
        if d > 0.002:
            diffs.append(f"{m}: recomputed {results[method][m]} vs paper {pdict[m]}")
    if diffs:
        all_ok = False
        print(f"  MISMATCH {method}: " + "; ".join(diffs))
    else:
        print(f"  OK {method}: all 7 metrics match (max diff <= 0.002)")
print("\nVERDICT:", "ALL MATCH" if all_ok else "MISMATCHES FOUND")
