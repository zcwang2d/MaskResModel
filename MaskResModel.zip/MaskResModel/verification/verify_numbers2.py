# -*- coding: utf-8 -*-
"""
Verification pass #1 (two-way, document <-> artifacts).

A. Forward : every authoritative value from CSV/JSON artifacts must appear in the docx
             (tables + body + math runs).
B. Reverse : every numeric token found in the docx must be traceable to an artifact
             value, a derived value recomputed from artifacts, or a documented
             structural constant. Unclassified tokens are listed for manual review.
C. Structure: method/variant names in tables, caption numbering (Figs 1-8, Tables 1-4),
             equation numbering (1)-(14), reference numbering [1]-[36] and in-text
             citation coverage.
Output: paper_build/verify2_report.txt
"""
import csv
import json
import os
import re

from docx import Document
from docx.oxml.ns import qn

ROOT = r"C:\Users\zcwan\Desktop\多模态\IRVIS_Fusion_SCI"
DOCX = r"C:\Users\zcwan\Desktop\多模态\MaskResModel_IRVIS_Fusion_SCI.docx"
REPORT = os.path.join(ROOT, "paper_build", "verify2_report.txt")

L = []


def log(s=""):
    L.append(s)
    print(s)


def load_csv(p):
    with open(p, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def load_json(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


# ---------------- docx extraction ----------------
def docx_texts():
    d = Document(DOCX)
    body = []
    for p in d.paragraphs:
        body.append(p.text)
    for t in d.tables:
        for row in t.rows:
            for c in row.cells:
                body.append(c.text)
    return d, "\n".join(body)


def math_texts(doc):
    out = []
    for mt in doc.element.body.iter(qn("m:t")):
        if mt.text:
            out.append(mt.text)
    return "".join(out)


def candidate_strings(f):
    """all reasonable string renderings of a float for matching"""
    cs = set()
    cs.add("%.4f" % f)
    cs.add("%.3f" % f)
    cs.add("%.2f" % f)
    cs.add("%.1f" % f)
    for s in list(cs):
        cs.add(s.rstrip("0").rstrip("."))
    if f == int(f):
        cs.add(str(int(f)))
    return cs


# ---------------- artifact value set ----------------
def build_expected():
    exp = {}
    for tag, path in [
        ("tno", os.path.join(ROOT, "metrics", "all_metrics_tno.csv")),
        ("road", os.path.join(ROOT, "metrics", "all_metrics_roadscene_test.csv")),
    ]:
        for row in load_csv(path):
            m = row["method"]
            for k in ["EN", "SD", "SF", "AG", "SSIM_VIS", "SSIM_IR", "MI"]:
                exp["%s|%s|%s" % (tag, m, k)] = float(row[k])
    for row in load_csv(os.path.join(ROOT, "metrics", "efficiency_proposed.csv")):
        exp["eff|%s|params" % row["method"]] = float(row["params_M"])
        exp["eff|%s|flops" % row["method"]] = float(row["flops_G"])
    for row in load_csv(os.path.join(ROOT, "metrics", "efficiency_baselines.csv")):
        if row["method"] in ("DWT", "GTF"):
            continue
        exp["eff|%s|params" % row["method"]] = float(row["params_M"])
        if row["flops_G"] not in ("n/a", ""):
            exp["eff|%s|flops" % row["method"]] = float(row["flops_G"])
    # baseline inference times: authoritative source = baselines_summary.json (real TNO images)
    bsum = load_json(os.path.join(ROOT, "metrics", "baselines_summary.json"))
    for m, v in bsum["methods"].items():
        exp["eff|%s|time_tno" % m] = float(v["time_ms"]["tno"]["mean"])
    # by-design omissions (present in CSVs but intentionally not printed in Table 4)
    bydesign = {
        "eff|Ours-no_rcm|flops",
        "eff|Ours-no_ltsm|flops",
    }
    full = load_json(os.path.join(ROOT, "runs", "full", "summary.json"))
    exp["train|best_epoch"] = float(full["best_epoch"])
    exp["train|best_loss"] = float(full["best_loss"])
    exp["train|lr"] = float(full["lr"])
    exp["train|batch"] = float(full["batch"])
    exp["train|seed"] = float(full["seed"])
    exp["train|threads"] = float(full["threads"])
    exp["train|epochs"] = float(full["epochs"])
    exp["train|res_w"] = float(full["res_w_used"])
    exp["train|ir_w"] = float(full["ir_w_used"])
    exp["train|tau"] = float(full["theta_tau"])
    for ds, tag in [("tno", "inf_tno"), ("roadscene_test", "inf_road")]:
        s = load_json(os.path.join(ROOT, "results", "proposed", "full", ds, "summary.json"))
        exp["%s|n_pairs" % tag] = float(s["n_pairs"])
        exp["%s|ms" % tag] = float(s["inference_ms_mean"])
    return exp, bydesign


# ---------------- reverse allowlist (structural constants, documented) ----------------
STRUCTURAL = {
    "0.05", "0.95", "0.45", "0.5", "0.75", "0.2", "0.85", "0.10", "0.15",
    "0.4", "0.6", "0.01", "0.005", "0.2M",
    "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14",
    "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26",
    "27", "28", "29", "30", "31", "32", "33", "34", "35", "36",
    "100", "256", "54", "40", "181", "42", "85", "8", "20", "12",
    "64", "128", "16",
    "1e-8", "1e-4", "1e-6", "3e-4", "1e-04", "1e-06",
    "2.13",
    "97.5", "8.8", "7.7", "4.7", "5.6", "2.9", "19", "5.9",
    "114", "125", "0.30", "19.67",
    "2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026",
    "2.680", "3.240", "3.433", "3.490", "0.722", "0.637", "113.6", "125.2",
}


def main():
    doc, body = docx_texts()
    mtext = math_texts(doc)
    all_text = body + "\n" + mtext

    # claim scope for reverse scanning: paragraphs before the "References" heading,
    # excluding the author/affiliation block, plus all table cells and math runs.
    paras = [p.text for p in doc.paragraphs]
    ref_idx = None
    for i, pt in enumerate(paras):
        if pt.strip() == "References":
            ref_idx = i
            break
    nonempty = [i for i, pt in enumerate(paras) if pt.strip()]
    drop = nonempty[3] + 1 if len(nonempty) > 3 else 0
    claim_paras = paras[drop:] if ref_idx is None else paras[drop:ref_idx]
    tbl_texts = []
    for t in doc.tables:
        for row in t.rows:
            for c in row.cells:
                tbl_texts.append(c.text)
    claim_text = "\n".join(claim_paras + tbl_texts) + "\n" + mtext

    exp, bydesign = build_expected()

    # ---------- A. forward ----------
    log("===== PASS 1A : FORWARD (artifact -> docx) =====")
    missing = []
    for label, v in sorted(exp.items()):
        cands = candidate_strings(v)
        if not any(c in all_text for c in cands):
            missing.append((label, v, sorted(cands)[:3]))
    if missing:
        for m in missing:
            tag = "BY-DESIGN-OMISSION" if m[0] in bydesign else "MISS"
            log("%s %s = %s (tried %s)" % (tag, m[0], m[1], m[2]))
    else:
        log("ALL %d artifact values found in docx." % len(exp))
    n_miss_a = len([m for m in missing if m[0] not in bydesign])

    # ---------- B. reverse ----------
    log("")
    log("===== PASS 1B : REVERSE (claim numbers -> traceability; scope = body before "
        "References + tables + equations) =====")
    token_re = re.compile(r"\d+(?:\.\d+)?(?:e[-−]\d+)?")
    found = set()
    for m in token_re.finditer(claim_text):
        found.add(m.group(0))
    # also capture percent / multiplier numbers
    for m in re.finditer(r"(\d+(?:\.\d+)?)\s*[%×x\u00d7]", claim_text):
        found.add(m.group(1))

    allowed = set()
    for label, v in exp.items():
        allowed |= candidate_strings(v)
    # derived values (documented in verify_derived.py; mirrored here for reverse tracing)
    derived = {
        # percentages / ratios / fps / minutes / diffs (computed from CSVs in this script)
    }
    tno = {r["method"]: r for r in load_csv(os.path.join(ROOT, "metrics", "all_metrics_tno.csv"))}
    road = {r["method"]: r for r in load_csv(os.path.join(ROOT, "metrics", "all_metrics_roadscene_test.csv"))}
    calc = {}
    calc["pct_gtf"] = (float(tno["Ours-full"]["MI"]) - float(tno["GTF"]["MI"])) / float(tno["GTF"]["MI"]) * 100
    calc["pct_df"] = (float(road["Ours-full"]["MI"]) - float(road["DenseFuse"]["MI"])) / float(road["DenseFuse"]["MI"]) * 100
    calc["pct_en"] = (float(tno["RFN_Nest"]["EN"]) - float(tno["Ours-full"]["EN"])) / float(tno["RFN_Nest"]["EN"]) * 100
    calc["r_rfn"] = 7.5242 / 0.3006
    calc["r_fgan"] = 0.9256 / 0.3006
    calc["r_flops_rfn"] = 111.1059 / 19.6671
    calc["r_flops_fgan"] = 56.8177 / 19.6671
    calc["r_time_rfn"] = 2154.6 / 113.585
    calc["r_time_fgan"] = 665.3 / 113.585
    calc["fps"] = 1000.0 / 113.585
    calc["min"] = 5848.3 / 60.0
    calc["den_tno"] = float(tno["Ours-full"]["EN"]) - float(tno["Ours-no_rcm"]["EN"])
    calc["dsd_tno"] = float(tno["Ours-full"]["SD"]) - float(tno["Ours-no_rcm"]["SD"])
    calc["dssim_tno"] = float(tno["Ours-full"]["SSIM_VIS"]) - float(tno["Ours-no_afhs"]["SSIM_VIS"])
    calc["dssim_road"] = float(road["Ours-full"]["SSIM_VIS"]) - float(road["Ours-no_afhs"]["SSIM_VIS"])
    calc["ms_road"] = float(load_json(os.path.join(ROOT, "results", "proposed", "full", "roadscene_test", "summary.json"))["inference_ms_mean"])
    for k, v in calc.items():
        allowed |= candidate_strings(v)

    allowed |= STRUCTURAL
    # round-trip normalizations (include integers and scientific forms)
    norm_allowed = set()
    for a in allowed:
        try:
            norm_allowed.add(str(float(a)))
        except ValueError:
            pass
    for t in list(found):
        t2 = t.replace("\u2212", "-")
        try:
            fv = float(t2)
            if any(abs(fv - float(x)) < 0.001 for x in norm_allowed):
                found.discard(t)
        except ValueError:
            pass
    unclassified = sorted(found)
    log("Numeric tokens scanned: %d; unclassified: %d" % (len(found) + len(allowed), len(unclassified)))
    # precise context: word-boundary match with surroundings, across paras/tables/math
    all_segs = [("P", p) for p in claim_paras] + [("T", x) for x in tbl_texts] + [("M", x) for x in re.split(r"\s+", mtext)]
    for u in unclassified:
        pat = re.compile(r"(?<![0-9.])(?:%s)(?![0-9.])" % re.escape(u))
        ctxs = []
        for kind, seg in all_segs:
            for m in pat.finditer(seg):
                s = max(0, m.start() - 45)
                ctxs.append("%s|...%s..." % (kind, seg[s:m.end() + 45].replace("\n", " ")))
                if len(ctxs) >= 2:
                    break
            if len(ctxs) >= 2:
                break
        log("UNCLASSIFIED %s | %s" % (u, " || ".join(ctxs) if ctxs else "(no isolated occurrence)"))

    # ---------- C. structure ----------
    log("")
    log("===== PASS 1C : STRUCTURE =====")
    ok = True
    # figures / tables captions
    for i in range(1, 9):
        if "Fig. %d." % i not in body:
            log("STRUCT MISS Fig. %d" % i)
            ok = False
    for i in range(1, 5):
        if "Table %d." % i not in body:
            log("STRUCT MISS Table %d" % i)
            ok = False
    for i in range(1, 15):
        if "(%d)" % i not in body:
            log("STRUCT MISS Eq.(%d)" % i)
            ok = False
    # references
    for i in range(1, 37):
        if "[%d]" % i not in body:
            log("STRUCT MISS ref [%d]" % i)
            ok = False
    # in-text citation coverage: every ref cited somewhere in body BEFORE References heading
    head_idx = body.find("References")
    body_main = body[:head_idx] if head_idx != -1 else body
    uncited = [i for i in range(1, 37) if "[%d]" % i not in body_main]
    if uncited:
        log("STRUCT refs never cited in body: %s" % uncited)
        ok = False
    # method names in tables 1/2
    tno_rows = {r["method"] for r in load_csv(os.path.join(ROOT, "metrics", "all_metrics_tno.csv"))[:6]}
    for mname in ["DWT", "GTF", "DenseFuse", "RFN-Nest", "FusionGAN", "Ours"]:
        if mname not in body:
            log("STRUCT MISS method name %s" % mname)
            ok = False
    log("STRUCT %s" % ("OK" if ok else "ISSUES ABOVE"))
    log("")
    log("RESULT: %s" % ("PASS (forward clean; reverse/structure reviewed)" if n_miss_a == 0 and ok else "REVIEW REQUIRED"))
    with open(REPORT, "w", encoding="utf-8") as f:
        f.write("\n".join(L))


if __name__ == "__main__":
    main()
