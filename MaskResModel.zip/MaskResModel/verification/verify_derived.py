# -*- coding: utf-8 -*-
"""
Verification pass #2 (independent re-computation of every derived claim).

Does NOT read numbers out of the docx. Instead it re-computes every derived
statement of the paper (percentages, ratios, fps, training minutes, ablation
deltas, rankings, best-baseline claims, range claims) directly from the CSV/JSON
artifacts, then asserts that the formatted claim string appears in the docx text.

Output: paper_build/verify_derived_report.txt
"""
import csv
import json
import os
import re

from docx import Document
from docx.oxml.ns import qn

ROOT = r"C:\Users\zcwan\Desktop\多模态\IRVIS_Fusion_SCI"
DOCX = r"C:\Users\zcwan\Desktop\多模态\MaskResModel_IRVIS_Fusion_SCI.docx"
REPORT = os.path.join(ROOT, "paper_build", "verify_derived_report.txt")

L = []


def log(s=""):
    L.append(s)
    print(s)


def load_csv(p):
    with open(p, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def load_json(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def doc_text():
    d = Document(DOCX)
    parts = [p.text for p in d.paragraphs]
    for t in d.tables:
        for row in t.rows:
            for c in row.cells:
                parts.append(c.text)
    for mt in d.element.body.iter(qn("m:t")):
        if mt.text:
            parts.append(mt.text)
    return "\n".join(parts)


def fmt(v, nd=1):
    return ("%." + str(nd) + "f") % v


def has(text, *cands):
    return any(c in text for c in cands)


def main():
    text = doc_text()
    tno = {r["method"]: r for r in load_csv(os.path.join(ROOT, "metrics", "all_metrics_tno.csv"))}
    road = {r["method"]: r for r in load_csv(os.path.join(ROOT, "metrics", "all_metrics_roadscene_test.csv"))}
    full = load_json(os.path.join(ROOT, "runs", "full", "summary.json"))
    inf_tno = load_json(os.path.join(ROOT, "results", "proposed", "full", "tno", "summary.json"))
    inf_road = load_json(os.path.join(ROOT, "results", "proposed", "full", "roadscene_test", "summary.json"))

    O_t, O_r = tno["Ours-full"], road["Ours-full"]
    fails = []

    def check(label, cond, detail=""):
        log("%s [%s] %s" % ("OK " if cond else "FAIL", label, detail))
        if not cond:
            fails.append(label)

    # ---- MI gains (percent vs best baseline) ----
    pct_gtf = (float(O_t["MI"]) - float(tno["GTF"]["MI"])) / float(tno["GTF"]["MI"]) * 100
    pct_df = (float(O_r["MI"]) - float(road["DenseFuse"]["MI"])) / float(road["DenseFuse"]["MI"]) * 100
    check("MI vs GTF TNO ~21%% (%.1f%%)" % pct_gtf,
          has(text, "21%", "21.4%"), "computed=%.2f%%" % pct_gtf)
    check("MI vs DenseFuse Road ~7.7%% (%.1f%%)" % pct_df,
          has(text, "7.7%", "7.72%"), "computed=%.2f%%" % pct_df)

    # ---- EN gap vs best baseline (TNO RFN-Nest) ----
    pct_en = (float(tno["RFN_Nest"]["EN"]) - float(O_t["EN"])) / float(tno["RFN_Nest"]["EN"]) * 100
    check("EN gap vs RFN-Nest TNO 4.7%% (%.1f%%)" % pct_en,
          has(text, "4.7%", "4.66%"), "computed=%.2f%%" % pct_en)

    # ---- ratio claims (params & FLOPs & time) ----
    r_rfn = 7.5242 / 0.3006
    r_fgan = 0.9256 / 0.3006
    r_fl_rfn = 111.1059 / 19.6671
    r_fl_fgan = 56.8177 / 19.6671
    r_t_rfn = 2154.6 / inf_tno["inference_ms_mean"]
    r_t_fgan = 665.3 / inf_tno["inference_ms_mean"]
    check("25x params vs RFN (%.2f)" % r_rfn, has(text, "25\u00d7", "25 x", "25x"), "computed=%.2f" % r_rfn)
    check("~3x params vs FusionGAN (%.2f)" % r_fgan, has(text, "about 3\u00d7", "3\u00d7"), "computed=%.2f" % r_fgan)
    check("5.6x FLOPs vs RFN (%.2f)" % r_fl_rfn, has(text, "5.6\u00d7", "5.6 x"), "computed=%.2f" % r_fl_rfn)
    check("2.9x FLOPs vs FusionGAN (%.2f)" % r_fl_fgan, has(text, "2.9\u00d7", "2.9 x"), "computed=%.2f" % r_fl_fgan)
    check("19x time vs RFN (%.2f)" % r_t_rfn, has(text, "19\u00d7", "19 x"), "computed=%.2f" % r_t_rfn)
    check("5.9x time vs FusionGAN (%.2f)" % r_t_fgan, has(text, "5.9\u00d7", "5.9 x"), "computed=%.2f" % r_t_fgan)

    # ---- fps & minutes ----
    fps = 1000.0 / inf_tno["inference_ms_mean"]
    minutes = full["elapsed_sec"] / 60.0
    check("8.8 fps (%.2f)" % fps, has(text, "8.8 fps"), "computed=%.2f" % fps)
    check("97.5 min (%.2f)" % minutes, has(text, "97.5"), "computed=%.2f" % minutes)

    # ---- precise CPU times & range claim ----
    ms_t = inf_tno["inference_ms_mean"]
    ms_r = inf_road["inference_ms_mean"]
    check("113.6 ms TNO (%.1f)" % ms_t, has(text, "113.6"), "computed=%.1f" % ms_t)
    check("125.2 ms Road (%.1f)" % ms_r, has(text, "125.2"), "computed=%.1f" % ms_r)
    check("range 114-125 ms", has(text, "114\u2013125", "114-125"), "from %.1f..%.1f" % (ms_t, ms_r))

    # ---- ablation deltas ----
    den_t = float(O_t["EN"]) - float(tno["Ours-no_rcm"]["EN"])
    dsd_t = float(O_t["SD"]) - float(tno["Ours-no_rcm"]["SD"])
    dssim_t = float(O_t["SSIM_VIS"]) - float(tno["Ours-no_afhs"]["SSIM_VIS"])
    dssim_r = float(O_r["SSIM_VIS"]) - float(road["Ours-no_afhs"]["SSIM_VIS"])
    check("EN 6.808->6.588 (delta %.4f)" % den_t,
          has(text, "6.808\u21926.588", "6.808->6.588", "6.808\u2192 6.588"), "computed=%.4f" % den_t)
    check("SD 34.60->30.42 (delta %.4f)" % dsd_t,
          has(text, "34.60\u219230.42", "34.60->30.42"), "computed=%.4f" % dsd_t)
    check("SSIM_VIS TNO 0.7216->0.7178 (delta %.4f)" % dssim_t,
          has(text, "0.7216\u21920.7178"), "computed=%.4f" % dssim_t)
    check("SSIM_VIS Road 0.6368->0.6342 (delta %.4f)" % dssim_r,
          has(text, "0.6368\u21920.6342"), "computed=%.4f" % dssim_r)

    # ---- rankings & best-baseline claims (6 compared methods only) ----
    METHODS = {"DWT", "GTF", "DenseFuse", "RFN_Nest", "FusionGAN", "Ours-full"}
    mi_t = {m: float(v["MI"]) for m, v in tno.items() if m in METHODS}
    mi_r = {m: float(v["MI"]) for m, v in road.items() if m in METHODS}
    check("MI rank #1 TNO (6 methods)", max(mi_t.values()) == float(O_t["MI"]),
          "best=%.4f (%s)" % (max(mi_t.values()), max(mi_t, key=mi_t.get)))
    check("MI rank #1 Road (6 methods)", max(mi_r.values()) == float(O_r["MI"]),
          "best=%.4f (%s)" % (max(mi_r.values()), max(mi_r, key=mi_r.get)))
    en_t = {m: float(v["EN"]) for m, v in tno.items() if m in METHODS}
    en_r = {m: float(v["EN"]) for m, v in road.items() if m in METHODS}
    check("best-EN baseline TNO = RFN-Nest", max(en_t, key=en_t.get) == "RFN_Nest",
          "best=%s" % max(en_t, key=en_t.get))
    check("best-EN baseline Road = RFN-Nest", max(en_r, key=en_r.get) == "RFN_Nest",
          "best=%s" % max(en_r, key=en_r.get))
    sf_t = {m: float(v["SF"]) for m, v in tno.items() if m in METHODS}
    sf_r = {m: float(v["SF"]) for m, v in road.items() if m in METHODS}
    check("best-SF method TNO = DWT", max(sf_t, key=sf_t.get) == "DWT", "best=%s" % max(sf_t, key=sf_t.get))
    check("best-SF method Road = DWT", max(sf_r, key=sf_r.get) == "DWT", "best=%s" % max(sf_r, key=sf_r.get))
    ssim_t = {m: float(v["SSIM_VIS"]) for m, v in tno.items() if m in METHODS}
    ssim_r = {m: float(v["SSIM_VIS"]) for m, v in road.items() if m in METHODS}
    check("SSIM_VIS TNO rank #2 claim (0.722)", sorted(ssim_t.values(), reverse=True)[1] == float(O_t["SSIM_VIS"]),
          "rank2=%.4f (%s)" % (sorted(ssim_t.values(), reverse=True)[1],
                               [m for m in ssim_t if ssim_t[m] == sorted(ssim_t.values(), reverse=True)[1]]))
    check("SSIM_VIS Road rank #3 claim (0.637)",
          sorted(ssim_r.values(), reverse=True)[2] == float(O_r["SSIM_VIS"]),
          "rank3=%.4f (%s)" % (sorted(ssim_r.values(), reverse=True)[2],
                               [m for m in ssim_r if ssim_r[m] == sorted(ssim_r.values(), reverse=True)[2]]))
    check("FusionGAN SSIM_VIS ~0.30 (%.2f)" % float(tno["FusionGAN"]["SSIM_VIS"]),
          has(text, "0.30"), "computed=%.4f" % float(tno["FusionGAN"]["SSIM_VIS"]))

    # ---- AFHS learned values ----
    check("sigma(w_r)=0.527 (%.4f)" % full["res_w_used"], has(text, "0.527"), "computed=%.4f" % full["res_w_used"])
    check("sigma(w_ir)=0.540 (%.4f)" % full["ir_w_used"], has(text, "0.540"), "computed=%.4f" % full["ir_w_used"])
    check("tau=0.893 (%.4f)" % full["theta_tau"], has(text, "0.893"), "computed=%.4f" % full["theta_tau"])

    # ---- hyperparameter & best-model claims ----
    check("epochs 100", has(text, "100 epochs"))
    check("lr 1e-4", has(text, "1e\u22124", "1e-4"))
    check("cosine 1e-6", has(text, "1e\u22126", "1e-6"))
    check("batch 10", has(text, "batch size of 10"))
    check("clip 0.5", has(text, "0.5"))
    check("seed 42", has(text, "seed of 42"))
    check("threads 12", has(text, "12 threads"))
    check("best epoch 85", has(text, "epoch 85"))
    check("best loss 0.0551 (%.4f)" % full["best_loss"], has(text, "0.0551"), "computed=%.4f" % full["best_loss"])
    check("pairs 181/54/40", has(text, "181") and has(text, "54") and has(text, "40"))
    check("256x256", has(text, "256\u00d7256", "256x256"))

    log("")
    log("RESULT: %s" % ("ALL DERIVED CLAIMS VERIFIED" if not fails else "FAILED: %s" % fails))
    with open(REPORT, "w", encoding="utf-8") as f:
        f.write("\n".join(L))


if __name__ == "__main__":
    main()
