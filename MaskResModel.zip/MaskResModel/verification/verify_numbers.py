# -*- coding: utf-8 -*-
"""
Re-verification: cross-check every numeric claim in the manuscript docx against
the locally produced CSV/JSON artifacts. Prints a report and writes it to
paper_build/verification_report.txt
"""
import csv
import json
import os
import re

from docx import Document

ROOT = r"C:\Users\zcwan\Desktop\多模态\IRVIS_Fusion_SCI"
DOCX = r"C:\Users\zcwan\Desktop\多模态\MaskResModel_IRVIS_Fusion_SCI.docx"
REPORT = os.path.join(ROOT, "paper_build", "verification_report.txt")

lines = []


def log(s=""):
    lines.append(s)
    print(s)


def load_csv(path):
    with open(path, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def load_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def docx_all_text():
    d = Document(DOCX)
    texts = [p.text for p in d.paragraphs]
    for t in d.tables:
        for row in t.rows:
            for c in row.cells:
                texts.append(c.text)
    return "\n".join(texts)


def norm(x):
    # normalize numeric strings: drop trailing zeros, unify minus
    s = str(x).strip().replace("\u2212", "-").replace(",", "")
    return s


def check(label, expected_values, doc_text, tol=0.0005):
    """expected_values: list of floats/ints. Check each appears in doc_text
    (as rounded 3-decimal or exact short form)."""
    missing = []
    for v in expected_values:
        f = float(v)
        candidates = set()
        candidates.add("%.4f" % f)
        candidates.add("%.3f" % f)
        candidates.add("%.2f" % f)
        candidates.add("%.1f" % f)
        candidates.add(("%.4f" % f).rstrip("0").rstrip("."))
        candidates.add(("%.3f" % f).rstrip("0").rstrip("."))
        if f == int(f):
            candidates.add(str(int(f)))
        hit = any(c in doc_text for c in candidates)
        if not hit:
            missing.append((v, sorted(candidates)[:2]))
    status = "OK " if not missing else "MISS"
    log("%s [%s] %s" % (status, label, ("all found" if not missing else "missing=%s" % missing)))
    return not missing


def main():
    doc_text = docx_all_text()
    all_ok = True

    # ---- Tables 1/2 : TNO & RoadScene metrics ----
    tno = load_csv(os.path.join(ROOT, "metrics", "all_metrics_tno.csv"))
    road = load_csv(os.path.join(ROOT, "metrics", "all_metrics_roadscene_test.csv"))
    log("== Tables 1 & 2 (quantitative) ==")
    for row in tno:
        m = row["method"]
        for k in ["EN", "SD", "SF", "AG", "SSIM_VIS", "SSIM_IR", "MI"]:
            all_ok &= check("TNO %s %s" % (m, k), [row[k]], doc_text)
    for row in road:
        m = row["method"]
        for k in ["EN", "SD", "SF", "AG", "SSIM_VIS", "SSIM_IR", "MI"]:
            all_ok &= check("ROAD %s %s" % (m, k), [row[k]], doc_text)

    # ---- Table 3 : ablation ----
    log("== Table 3 (ablation) ==")
    abl = {
        "TNO": load_csv(os.path.join(ROOT, "metrics", "all_metrics_tno.csv"))[5:],
        "ROAD": load_csv(os.path.join(ROOT, "metrics", "all_metrics_roadscene_test.csv"))[5:],
    }
    for ds, rows in abl.items():
        for row in rows:
            m = row["method"]
            for k in ["EN", "SD", "SF", "SSIM_VIS", "SSIM_IR", "MI"]:
                all_ok &= check("%s %s %s" % (ds, m, k), [row[k]], doc_text)

    # ---- Table 4 : efficiency ----
    log("== Table 4 (efficiency) ==")
    effp = load_csv(os.path.join(ROOT, "metrics", "efficiency_proposed.csv"))
    effb = load_csv(os.path.join(ROOT, "metrics", "efficiency_baselines.csv"))
    for row in effp:
        all_ok &= check("EFF proposed %s params" % row["method"], [row["params_M"]], doc_text)
        if row.get("flops_G"):
            all_ok &= check("EFF proposed %s flops" % row["method"], [row["flops_G"]], doc_text)
    for row in effb:
        if row["method"] in ("DWT", "GTF"):
            continue
        all_ok &= check("EFF base %s params" % row["method"], [row["params_M"]], doc_text)
        if row.get("flops_G") and row["flops_G"] != "n/a":
            all_ok &= check("EFF base %s flops" % row["method"], [row["flops_G"]], doc_text)

    # ---- Training summary / AFHS / inference ----
    log("== Training summary / AFHS / inference ==")
    full = load_json(os.path.join(ROOT, "runs", "full", "summary.json"))
    all_ok &= check("best_epoch", [full["best_epoch"]], doc_text)
    all_ok &= check("best_loss", [full["best_loss"]], doc_text)
    all_ok &= check("epochs", [full["epochs"]], doc_text)
    all_ok &= check("lr", [full["lr"]], doc_text)
    all_ok &= check("batch", [full["batch"]], doc_text)
    all_ok &= check("seed", [full["seed"]], doc_text)
    all_ok &= check("threads", [full["threads"]], doc_text)
    all_ok &= check("elapsed_min", [97.5], doc_text)
    all_ok &= check("res_w_used", [full["res_w_used"]], doc_text)
    all_ok &= check("ir_w_used", [full["ir_w_used"]], doc_text)
    all_ok &= check("theta_tau", [full["theta_tau"]], doc_text)
    for ds in ["tno", "roadscene_test"]:
        s = load_json(os.path.join(ROOT, "results", "proposed", "full", ds, "summary.json"))
        all_ok &= check("inf %s n_pairs" % ds, [s["n_pairs"]], doc_text)
        all_ok &= check("inf %s ms" % ds, [s["inference_ms_mean"]], doc_text, tol=1.0)

    # ---- narrative key numbers ----
    log("== Narrative key numbers ==")
    narr = {
        "params 0.30": [0.3006],
        "flops 19.67": [19.6671],
        "MI tno 3.433": [3.4326],
        "MI road 3.490": [3.4899],
        "MI baseline GTF 2.8286 (21%)": [2.8286],
        "MI baseline DenseFuse 3.2398 (7.7%)": [3.2398],
        "EN tno 6.808": [6.8078],
        "EN road 7.137": [7.1367],
        "EN best RFN 7.1409": [7.1409],
        "EN best road RFN 7.4591": [7.4591],
        "SF tno 7.517": [7.5172],
        "SF road 7.648": [7.6477],
        "SF DWT 8.2702": [8.2702],
        "SSIM_VIS tno 0.722": [0.7216],
        "SSIM_VIS road 0.637": [0.6368],
        "SSIM_IR tno": [0.598],
        "SSIM_IR road": [0.6165],
        "FusionGAN ssim_vis 0.30": [0.3002, 0.3018],
        "CPU 113.6": [113.585],
        "CPU road 125.2": [125.24],
        "DenseFuse params 0.0742": [0.0742],
        "DenseFuse flops 5.77": [5.7661],
        "DenseFuse time 236": [236.1],
        "RFN params 7.52": [7.5242],
        "RFN flops 111.1": [111.1059],
        "RFN time 2154.6": [2154.6],
        "FusionGAN params 0.9256": [0.9256],
        "FusionGAN flops 56.82": [56.8177],
        "FusionGAN time 665.3": [665.3],
        "train pairs 181": [181],
        "tno pairs 54": [54],
        "road pairs 40": [40],
        "AFHS sigma(res_w) 0.527": [0.5265823006629944],
        "AFHS sigma(ir_w) 0.540": [0.5400223135948181],
        "AFHS tau 0.893": [0.8931544899940491],
        "epoch 85": [85],
        "loss 0.0551": [0.055055],
        "elapsed 97.5 min": [97.5],
        "ablation en 6.808->6.588": [6.8078, 6.5877],
        "ablation sd 34.60->30.42": [34.5985, 30.4224],
        "no_afhs ssim tno 0.7216->0.7178": [0.7216, 0.7178],
        "no_afhs ssim road 0.6368->0.6342": [0.6368, 0.6342],
    }
    for label, vals in narr.items():
        all_ok &= check(label, vals, doc_text)

    log("")
    log("RESULT: %s" % ("ALL NUMBERS VERIFIED" if all_ok else "SOME NUMBERS MISSING - CHECK ABOVE"))
    with open(REPORT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


if __name__ == "__main__":
    main()
