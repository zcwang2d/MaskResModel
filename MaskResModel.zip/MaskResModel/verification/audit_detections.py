# -*- coding: utf-8 -*-
"""Recompute paper/yolo/summary.json from detections.jsonl and diff every field."""
import json
import numpy as np

ORDER = ['IR', 'VIS', 'DWT', 'GTF', 'DenseFuse', 'RFN-Nest', 'FusionGAN', 'TarDAL', 'Ours']
recs = {}
for line in open(r'C:\Users\zcwan\Documents\Kimi\Workspaces\多模态优化\paper\yolo\detections.jsonl', encoding='utf-8'):
    r = json.loads(line)
    recs[(r['pair'], r['method'])] = r
pairs = sorted(set(r['pair'] for r in recs.values()))
print('pairs:', len(pairs), 'records:', len(recs))

def norm(dets, shape):
    h, w = shape
    return [[d[0]/w, d[1]/h, d[2]/w, d[3]/h, d[4], d[5]] for d in dets]

def iou(a, b):
    x1, y1 = max(a[0], b[0]), max(a[1], b[1])
    x2, y2 = min(a[2], b[2]), min(a[3], b[3])
    iw, ih = max(0, x2 - x1), max(0, y2 - y1)
    inter = iw * ih
    return inter / max(1e-9, (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - inter)

def match(gt, dets, thr=0.5):
    matched = 0
    for cls in set(g[5] for g in gt):
        gcls = [g for g in gt if g[5] == cls]
        dcls = [d for d in dets if d[5] == cls]
        used = set()
        for g in sorted(gcls, key=lambda g: -g[4]):
            best, bi = thr, -1
            for i, d in enumerate(dcls):
                if i in used:
                    continue
                v = iou(g, d)
                if v >= best:
                    best, bi = v, i
            if bi >= 0:
                used.add(bi)
                matched += 1
    return matched

nd = {k: norm(r['dets'], r['shape']) for k, r in recs.items()}
old = json.load(open(r'C:\Users\zcwan\Documents\Kimi\Workspaces\多模态优化\paper\yolo\summary.json', encoding='utf-8'))

all_ok = True
for m in ORDER:
    tot, per, veh, rate, conf, rec = [], [], [], [], [], []
    for p in pairs:
        c = recs[(p, m)]['ct0.25']
        tot.append(c['total']); per.append(c['person']); veh.append(c['vehicle'])
        rate.append(1 if c['total'] > 0 else 0)
        if c['total'] > 0:
            conf.append(c['mean_conf'])
        gt = nd[(p, 'IR')] + nd[(p, 'VIS')]
        if gt:
            rec.append(match(gt, nd[(p, m)]) / len(gt))
    new = {'avg_total': float(np.mean(tot)), 'avg_person': float(np.mean(per)),
           'avg_vehicle': float(np.mean(veh)), 'det_rate': float(np.mean(rate)),
           'mean_conf': float(np.mean(conf)) if conf else 0.0,
           'pseudo_recall': float(np.mean(rec))}
    diffs = {k: (round(new[k], 6), round(old[m][k], 6)) for k in new
             if abs(new[k] - old[m][k]) > 1e-6}
    if diffs:
        all_ok = False
        print(f'MISMATCH {m}: {diffs}')
    else:
        print(f'OK {m}: avg_total={new["avg_total"]:.3f} person={new["avg_person"]:.3f} '
              f'vehicle={new["avg_vehicle"]:.3f} det_rate={new["det_rate"]:.3f} '
              f'conf={new["mean_conf"]:.4f} recall={new["pseudo_recall"]:.4f}')
print('\nVERDICT:', 'ALL MATCH' if all_ok else 'MISMATCHES FOUND')
