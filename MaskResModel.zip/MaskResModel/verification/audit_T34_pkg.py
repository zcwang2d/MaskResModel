# -*- coding: utf-8 -*-
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
"""Audit ablation Table 3 and efficiency Table 4 of the manuscript."""
import csv
import json
import os
import sys

import cv2
import numpy as np
from docx import Document

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from maskresmodel.imgio import imread_gray  # noqa: E402

WS = r'C:\Users\zcwan\Documents\Kimi\Workspaces\多模态优化'
ROOT = r'C:\Users\zcwan\Desktop\多模态\IRVIS_Fusion_SCI'
DOCX = r'C:\Users\zcwan\Desktop\多模态\image20261008\01_Manuscript_MaskResModel.docx'

SUPP = DOCX.replace('01_Manuscript_MaskResModel', '08_Supplementary_Material')
t3 = t4 = None
for _tbl in Document(SUPP).tables:
    _hdr = [c.text.strip() for c in _tbl.rows[0].cells]
    if _hdr[:2] == ['Variant', 'EN'] and 'MI' in _hdr:
        t3 = [[c.text.strip() for c in r.cells] for r in _tbl.rows]
    elif _hdr[:3] == ['Method', 'Params (M)', 'FLOPs (G)']:
        t4 = [[c.text.strip() for c in r.cells] for r in _tbl.rows]
assert t3 and t4, 'Table S3/S4 not located in supplement'

VARIANTS = {'full': 'Full', 'no_afhs': 'w/o AFHS', 'no_rcm': 'w/o RCEM',
            'no_ltsm': 'w/o LTSM', 'no_multi': 'w/o multi-loss'}
METRICS = ['EN', 'SD', 'SF', 'AG', 'SSIM_VIS', 'SSIM_IR', 'MI']

all_ok = True
# ---- Table 3 vs per-variant summary.json ----
paper3 = {}
for row in t3[1:]:
    paper3[row[0]] = [float(x) for x in row[1:]]
for vkey, vname in VARIANTS.items():
    for ds, dsname in [('tno', 'TNO'), ('roadscene_test', 'RoadScene')]:
        label = f'{vname} ({dsname})'
        row = paper3.get(label)
        if row is None:
            print(f'MISMATCH {label}: row missing in paper'); all_ok = False; continue
        spath = os.path.join(ROOT, 'results', 'proposed', vkey, ds, 'summary.json')
        d = json.load(open(spath, encoding='utf-8'))
        mm = d['means']
        # AG is absent from variant summaries: recompute from fused PNGs
        # (same definition as the main tables: mean Sobel magnitude / sqrt(2)).
        fused_dir = os.path.join(ROOT, 'results', 'proposed', vkey, ds, 'fused')
        ags = []
        for fn in sorted(os.listdir(fused_dir)):
            if fn.endswith('_mask.png') or fn.endswith('_res.png'):
                continue
            img = imread_gray(os.path.join(fused_dir, fn))
            g = img.astype(np.float64)
            sx = cv2.Sobel(g, cv2.CV_64F, 1, 0)
            sy = cv2.Sobel(g, cv2.CV_64F, 0, 1)
            ags.append(np.sqrt(sx ** 2 + sy ** 2).mean() / np.sqrt(2))
        mm = dict(mm)
        mm['AG'] = round(float(np.mean(ags)), 4)
        diffs = []
        for i, m in enumerate(METRICS):
            paper_v = mm.get(m)
            if paper_v is None:
                diffs.append(f'{m}: not in summary'); continue
            if abs(float(paper_v) - row[i]) > 0.002:
                diffs.append(f'{m}: summary {paper_v} vs paper {row[i]}')
        if diffs:
            all_ok = False
            print(f'MISMATCH {label}: ' + '; '.join(diffs))
        else:
            print(f'OK {label}')
print()
# ---- Table 4 vs baselines_summary.json + efficiency CSVs ----
bsum = json.load(open(os.path.join(ROOT, 'metrics', 'baselines_summary.json'), encoding='utf-8'))
eff_b = {r['method']: r for r in __import__('csv').DictReader(
    open(os.path.join(ROOT, 'metrics', 'efficiency_baselines.csv'), encoding='utf-8'))}
eff_p = {r['method']: r for r in __import__('csv').DictReader(
    open(os.path.join(ROOT, 'metrics', 'efficiency_proposed.csv'), encoding='utf-8'))}
for row in t4[1:]:
    m = row[0]
    mkey = 'RFN_Nest' if m == 'RFN-Nest' else m
    p_params = float(row[1]) if row[1] not in ('0', '–', '-') else 0.0
    p_flops = None if row[2] in ('–', '-') else float(row[2])
    p_time = float(row[3])
    src = bsum['methods'].get(mkey)
    if m == 'Ours':
        e = eff_p.get('Ours-full') or eff_p.get('Ours') or eff_p.get('full')
        s_time = json.load(open(os.path.join(
            ROOT, 'results', 'proposed', 'full', 'tno', 'summary.json'),
            encoding='utf-8'))['inference_ms_mean']
        s_params = float(e['params_M'])
        s_flops = e.get('flops_G')
    else:
        # Table 4 reports the TNO CPU times (per-dataset means in baselines_summary).
        s_time = src['time_ms']['tno']['mean']
        s_params = float(src['params_M'])
        s_flops = src.get('flops_G')
    diffs = []
    if abs(s_params - p_params) > 0.0005: diffs.append(f'params {s_params} vs {p_params}')
    if s_flops is not None and p_flops is not None and abs(float(s_flops) - p_flops) > 0.005:
        diffs.append(f'flops {s_flops} vs {p_flops}')
    if abs(s_time - p_time) > 0.05: diffs.append(f'time {s_time} vs {p_time}')
    if diffs:
        all_ok = False
        print(f'MISMATCH {m}: ' + '; '.join(diffs))
    else:
        print(f'OK {m}: params {p_params}M flops {p_flops} time {p_time}ms')

# ---- derived claim: 25x params, 19x speed vs RFN-Nest (TNO times) ----
rfn_p = bsum['methods']['RFN_Nest']['params_M']
rfn_t = bsum['methods']['RFN_Nest']['time_ms']['tno']['mean']
o_p = float(eff_p['Ours-full']['params_M'])
o_t = json.load(open(os.path.join(ROOT, 'results', 'proposed', 'full', 'tno',
                                  'summary.json'), encoding='utf-8'))['inference_ms_mean']
print(f'\nderived: RFN-Nest {rfn_p}M/{rfn_t:.1f}ms  Ours {o_p}M/{o_t:.1f}ms  '
      f'params ratio {rfn_p/o_p:.1f}x  time ratio {rfn_t/o_t:.1f}x')
print('\nVERDICT:', 'ALL MATCH' if all_ok else 'MISMATCHES FOUND')
