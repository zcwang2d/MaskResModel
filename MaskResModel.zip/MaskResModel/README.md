# MaskResModel 论文代码包

对应论文《MaskResModel: A Lightweight Infrared and Visible Image Fusion Network with Temperature-Aware Masking, Adaptive Residual Enhancement, and Highlight Suppression》（投稿 Scientific Reports）的全部算法与实验代码（绘图代码不随包发布）。

## 目录结构

```
code/
├── checkpoints/           训练好的模型权重（PyTorch .pth，CPU 训练，共 5 组 5.8 MB）
│   ├── full/model_best.pth        完整模型（论文主结果）
│   ├── no_afhs/model_best.pth     消融：AFHS 参数冻结
│   ├── no_rcm/model_best.pth      消融：去掉残差增强分支
│   ├── no_ltsm/model_best.pth     消融：手工掩膜替代 LTSM
│   └── no_multi/model_best.pth    消融：仅保留 L_mask + 0.4·L_res
│
├── maskresmodel/          核心算法包
│   ├── config.py          路径与通用超参（数据集位置、随机种子、图像尺寸，按需修改）
│   ├── model.py           MaskResModel = LTSM + RCEM + AFHS（含 full/no_afhs/no_rcm/no_ltsm 消融开关）
│   ├── loss.py            多约束复合损失（L_mask + 0.4·L_res + 0.6·L_bg + 0.01·L_range + 0.005·L_reg）
│   ├── dataset.py         红外/可见光配对数据集（256×256，水平翻转增广）
│   ├── imgio.py           图像读写（基于 PIL，兼容非 ASCII 路径）
│   └── metrics.py         EN / SD / SF / AG / SSIM_VIS / SSIM_IR / MI 七种指标
│
├── pipeline/              数据准备、训练与推理
│   ├── data_prep.py       构建训练/测试清单（RoadScene 221 对按 seed 42 划分 181 训练 + 40 测试）
│   ├── prep_train_256.py  训练集一次性缩放到 256×256
│   ├── tno_prep.py        TNO 原始数据预处理与自动配对
│   ├── tno_curate.py      TNO 测试集人工核对清单（54 对）
│   ├── train_fusion.py    训练入口（CPU，Adam + cosine annealing，100 epochs）
│   ├── probe.py           学习率探测（8 epochs/档，论文 Fig. 13）
│   ├── eval_fusion.py     推理 + 逐图指标 + 耗时统计（本方法与各消融变体）
│   ├── eval_tardal.py     TarDAL 基线推理（需 TarDAL 官方仓库 modules/，见下方说明）
│   └── efficiency.py      参数量 / FLOPs(fvcore) / CPU 单图推理时间（论文 Table 4、Fig. 10）
│
├── analysis/              论文补充分析实验
│   ├── post_analysis.py   汇总各方法指标，生成统一指标表
│   ├── sens_sweep.py      AFHS 参数逐一敏感性扫描（附加材料 Tables S5/S6）
│   ├── ft_sens.py         损失权重 warm-start 扰动微调（附加材料 Tables S8/S9）
│   └── loss_term_analysis.py  各项损失量级与占比分析（附加材料 Table S7）
│
├── detection/             下游目标检测评估（YOLOv8n，论文 Fig. 11/12）
│   ├── make_color_fused.py  基线灰度融合结果的 YCbCr 彩色重建
│   ├── detect.py            冻结 YOLOv8n（ONNX）逐图检测，多置信度阈值，JSONL 断点续跑
│   ├── analyze.py           汇总检测结果（检测数 / 成功率 / 伪真值召回）
│   └── gen_figs.py / gen_figs_userstyle.py  检测统计图与检测示意图绘制
│
│
└── verification/          数据核对脚本（从原始融合 PNG 重算指标并与论文表格比对）
    ├── audit_T12_pkg.py       审计正文 Table 1/2（用法: python audit_T12_pkg.py tno|road）
    ├── audit_T34_pkg.py       审计正文 Table 3/4
    ├── audit_detections.py    审计检测统计
    └── verify_derived.py / verify_detailed.py / verify_numbers.py / verify_numbers2.py
```

## 环境

Python 3.10+，CPU 即可运行全部实验：

```
pip install -r requirements.txt
```

## 快速体验

`examples/` 内有一对示例红外/可见光图像。训练好权重（或获取权重）后，在包根目录运行：

```
python pipeline/eval_fusion.py --run <权重目录，含 checkpoints/model_best.pth> --manifest examples/demo.csv --out demo_out
```

即可生成融合结果 `demo_out/fused/demo.png` 及全部指标。

## 运行顺序

0. 训练权重未随包提供（论文接收后发布）：先运行 `python pipeline/train_fusion.py` 自行训练 （CPU 即可完成，100 epochs），权重写入 `config.py` 中 `RUNS` 指定目录；`checkpoints/*/summary.json` 保留了各组训练配置与收敛信息供对照。
   注意运行顺序：先 `data_prep.py` 再 `tno_curate.py`。data_prep 生成的 tno.csv 为 0 行属正常（cv2 无法解码 TNO 的 BMP，TNO 测试清单由 PIL 版 tno_prep/tno_curate 生成，54 对人工核对）。
1. 修改 `maskresmodel/config.py` 中的 `ROOT`（实验根目录）及 `TNO_ROOT`、`ROAD_ROOT`（数据集路径）。
2. `python pipeline/data_prep.py` → `python pipeline/prep_train_256.py` → `python pipeline/tno_prep.py` / `tno_curate.py`
3. `python pipeline/probe.py`（学习率探测）→ `python pipeline/train_fusion.py`（正式训练）
4. `python pipeline/eval_fusion.py`（本方法推理与指标）→ `python pipeline/eval_tardal.py`、`python pipeline/efficiency.py`
5. 检测评估：`python detection/make_color_fused.py` → `python detection/detect.py` → `python detection/analyze.py`
6. 补充分析：`python analysis/` 下各脚本
7. 投稿前核对：`python verification/audit_T12_pkg.py tno` 等（全部输出 ALL MATCH 即与论文一致）

## 说明

- 跨模块导入已通过 `sys.path` 自动引导，所有脚本可在任意目录下直接 `python 路径/脚本.py` 运行。
- TarDAL 基线需其官方仓库（CVPR 2022, tardal++ 权重 v1.0.0）放在 `baselines_code` 目录；其余深度基线使用各官方发布权重。
- 检测使用 `yolov8n.onnx`（YOLOv8n COCO 预训练，导出为 ONNX），置于 detection/ 目录或由 ultralytics 自行导出。
- 所有指标均从实际融合输出图像重算，verification/ 中的审计脚本可完整复现论文 Table 1–4 与 Fig. 11 的全部数字。
