# -*- coding: utf-8 -*-
"""Central path configuration for the IR/Visible fusion experiment suite."""
import os

ROOT = r"C:\Users\zcwan\Desktop\多模态\IRVIS_Fusion_SCI"
CODE = os.path.join(ROOT, "code")
DATA = os.path.join(ROOT, "data")
RUNS = os.path.join(ROOT, "runs")
RESULTS = os.path.join(ROOT, "results")
BASELINES = os.path.join(ROOT, "baselines")
METRICS = os.path.join(ROOT, "metrics")
FIGURES = os.path.join(ROOT, "figures")
REPORT = os.path.join(ROOT, "report")

# Raw datasets
TNO_ROOT = r"C:\Users\zcwan\Desktop\数据集\TNO_Image_Fusion_Dataset\TNO_Image_Fusion_Dataset"
ROAD_ROOT = r"C:\Users\zcwan\Desktop\数据集\RoadScene-master\RoadScene-master"
ROAD_IR = os.path.join(ROAD_ROOT, "infrared")
ROAD_VIS = os.path.join(ROAD_ROOT, "crop_HR_visible")

IMG_SIZE = (256, 256)          # (W, H) as used by cv2.resize
SEED = 42
ROAD_TRAIN_N = 181            # RoadScene train split size (221 total, 40 held out)
