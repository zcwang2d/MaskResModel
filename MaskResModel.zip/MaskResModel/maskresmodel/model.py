# -*- coding: utf-8 -*-
"""
MaskResModel with ablation switches.
Identical to the conference-version architecture; the ``ablation`` flag only
disables one component at a time for the journal experiments:

  full      : LTSM + RCEM + AFHS (all learnable coefficients)
  no_afhs   : AFHS removed - res_w / ir_w / theta frozen at their initial values
  no_rcm    : RCEM removed - residual enhancement branch disabled (base = vis)
  no_ltsm   : LTSM removed - mask replaced by the hand-crafted normalized-IR mask
"""
import torch
import torch.nn as nn


class LTSM(nn.Module):
    """Lightweight temperature-saliency mask subnet (1 -> 64 -> 128 -> 64 -> 1)."""

    def __init__(self):
        super().__init__()
        self.layer = nn.Sequential(
            nn.Conv2d(1, 64, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 128, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 64, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 1, 3, padding=1),
        )

    def forward(self, x):
        return self.layer(x)


class RCEM(nn.Module):
    """Mask-guided residual enhancement subnet (4 -> 64 -> 128 -> 64 -> 3)."""

    def __init__(self):
        super().__init__()
        self.layer = nn.Sequential(
            nn.Conv2d(4, 64, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 128, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 64, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 3, 3, padding=1),
        )

    def forward(self, x, mask):
        x = torch.cat([x, mask], dim=1)
        res = self.layer(x)
        return res * mask


class MaskResModel(nn.Module):
    def __init__(self, ablation="full"):
        super().__init__()
        assert ablation in ("full", "no_afhs", "no_rcm", "no_ltsm", "no_multi")
        self.ablation = ablation
        self.mask_net = LTSM()
        self.res_net = RCEM()

        # AFHS: adaptive fusion hyper-parameters (learnable in the full model)
        self.res_w = nn.Parameter(torch.tensor(0.1))   # residual enhancement amplitude
        self.ir_w = nn.Parameter(torch.tensor(0.15))   # infrared fusion weight
        self.theta = nn.Parameter(torch.tensor(0.85))  # highlight-repair threshold

        if ablation == "no_afhs":
            for p in (self.res_w, self.ir_w, self.theta):
                p.requires_grad_(False)

    def _heuristic_mask(self, ir):
        """Per-sample min-max normalized IR used as the no-LTSM mask."""
        b = ir.shape[0]
        flat = ir.view(b, -1)
        mn = flat.min(dim=1, keepdim=True).values.view(b, 1, 1, 1)
        mx = flat.max(dim=1, keepdim=True).values.view(b, 1, 1, 1)
        return (ir - mn) / (mx - mn + 1e-8)

    def forward(self, ir, vis):
        if self.ablation == "no_ltsm":
            mask = self._heuristic_mask(ir)
        else:
            mask = self.mask_net(ir)
            mask = torch.tanh(mask) * 0.45 + 0.5

        # 2. residual enhancement (RCEM), skipped under no_rcm
        if self.ablation == "no_rcm":
            res = torch.zeros_like(vis)
            base = vis
        else:
            res = self.res_net(vis, mask)
            res = torch.tanh(res) * torch.sigmoid(self.res_w)
            base = vis + res

        # 3. infrared temperature-target fusion (learnable weight)
        ir_rgb = ir.repeat(1, 3, 1, 1)
        ir_weight = torch.sigmoid(self.ir_w)
        base = base * (1 - mask * ir_weight) + ir_rgb * (mask * ir_weight)

        # 4. adaptive highlight repair (learnable threshold)
        vis_gray = vis.mean(dim=1, keepdim=True)
        tau = torch.sigmoid(self.theta) * 0.2 + 0.75
        highlight_mask = torch.sigmoid((vis_gray - tau) * 20.0)
        fused = base * (1 - highlight_mask) + ir_rgb * highlight_mask

        fused = torch.clamp(fused, 0, 1)
        return fused, mask, res
