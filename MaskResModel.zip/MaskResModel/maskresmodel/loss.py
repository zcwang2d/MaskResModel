# -*- coding: utf-8 -*-
"""
Multi-constraint training loss for MaskResModel.

full   : mask L1 + 0.4*res L1 + 0.6*background-fidelity L1 + 0.01*range reg + 0.005*res reg
no_multi: only mask L1 + 0.4*res L1 (background fidelity and regularizers dropped)
"""
import torch
import torch.nn as nn


class MaskResLoss(nn.Module):
    def __init__(self, ablation="full"):
        super().__init__()
        self.ablation = ablation
        self.l1 = nn.L1Loss()

    def forward(self, ir, vis, mask, res, fused):
        # normalized IR supervision target for the mask
        ir_norm = (ir - ir.min()) / (ir.max() - ir.min() + 1e-8)

        loss_mask = self.l1(mask, ir_norm)

        if self.ablation == "no_rcm":
            loss_res = torch.zeros((), device=ir.device)
        else:
            loss_res = self.l1(res * mask, mask * 0.2)

        if self.ablation == "no_multi":
            total = loss_mask + 0.4 * loss_res
            return (total, loss_mask, loss_res,
                    torch.zeros((), device=ir.device),
                    torch.zeros((), device=ir.device),
                    torch.zeros((), device=ir.device))

        mask_3ch = mask.repeat(1, 3, 1, 1)
        loss_bg = self.l1(fused * (1 - mask_3ch), vis * (1 - mask_3ch))

        reg_lower = torch.mean(torch.relu(-fused))
        reg_upper = torch.mean(torch.relu(fused - 1.0))
        reg_range = reg_lower + reg_upper
        reg_res = torch.mean(torch.abs(res))

        total = (loss_mask + 0.4 * loss_res + 0.6 * loss_bg
                 + 0.01 * reg_range + 0.005 * reg_res)
        return total, loss_mask, loss_res, loss_bg, reg_range, reg_res
