# -*- coding: utf-8 -*-
"""Reference-free fusion metrics (EN / SD / SF / SSIM / MI) used for ALL methods."""
import numpy as np
import cv2
from skimage.metrics import structural_similarity


def _to_gray(img):
    if img.ndim == 3:
        return cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    return img


def _mutual_information(img1, img2, bins=256):
    hist_2d, _, _ = np.histogram2d(
        img1.ravel(), img2.ravel(), bins=bins, range=[[0, 255], [0, 255]])
    pxy = hist_2d / np.sum(hist_2d)
    px = np.sum(pxy, axis=1, keepdims=True)
    py = np.sum(pxy, axis=0, keepdims=True)
    eps = 1e-10
    return float(np.sum(pxy * np.log2(pxy / (px @ py + eps) + eps)))


def calculate_fusion_metrics(fused, vis=None, ir=None, data_range=255):
    """fused/vis/ir: uint8 RGB or grayscale arrays. Returns dict of metrics."""
    m = {}
    fg = _to_gray(fused)

    hist = cv2.calcHist([fg], [0], None, [256], [0, 256])
    hist_n = hist / hist.sum()
    m["EN"] = round(float(-np.sum(hist_n * np.log2(hist_n + 1e-8))), 4)
    m["SD"] = round(float(np.std(fg)), 4)

    dx = fg[:, 1:] - fg[:, :-1]
    dy = fg[1:, :] - fg[:-1, :]
    m["SF"] = round(float(np.sqrt(np.mean(dx ** 2) + np.mean(dy ** 2))), 4)

    if vis is not None:
        vg = _to_gray(vis)
        m["SSIM_VIS"] = round(float(structural_similarity(fg, vg, data_range=data_range)), 4)
        m["MI_VIS"] = round(_mutual_information(fg, vg), 4)
    if ir is not None:
        ig = _to_gray(ir)
        m["SSIM_IR"] = round(float(structural_similarity(fg, ig, data_range=data_range)), 4)
        m["MI_IR"] = round(_mutual_information(fg, ig), 4)
    if "MI_VIS" in m and "MI_IR" in m:
        m["MI"] = round(m["MI_VIS"] + m["MI_IR"], 4)
    return m
