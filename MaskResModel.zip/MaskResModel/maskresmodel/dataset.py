# -*- coding: utf-8 -*-
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
"""Paired IR/VIS dataset loader. All images resized to 256x256 (RGB order for VIS).
File I/O via PIL shim (cv2 cannot open non-ASCII paths on this host)."""
import csv
import random

import cv2
import numpy as np
import torch
from torch.utils.data import Dataset

from maskresmodel.config import IMG_SIZE, SEED
from maskresmodel.imgio import imread_gray, imread_rgb


def _read_manifest(path):
    rows = []
    with open(path, "r", encoding="utf-8", newline="") as f:
        for r in csv.DictReader(f):
            rows.append(r)
    return rows


class IRVISDataset(Dataset):
    def __init__(self, manifest_csv, img_size=IMG_SIZE, augment=False):
        self.rows = _read_manifest(manifest_csv)
        self.img_size = tuple(img_size)          # (W, H)
        self.augment = augment
        self._rng = random.Random(SEED)

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, idx):
        row = self.rows[idx]
        ir = imread_gray(row["ir_path"])
        vis = imread_rgb(row["vis_path"])

        ir = cv2.resize(ir, self.img_size)
        vis = cv2.resize(vis, self.img_size)

        if self.augment and self._rng.random() < 0.5:
            ir = np.fliplr(ir).copy()
            vis = np.fliplr(vis).copy()

        ir = (ir / 255.0).astype(np.float32)
        vis = (vis / 255.0).astype(np.float32)

        ir_t = torch.from_numpy(ir).unsqueeze(0)          # [1,H,W]
        vis_t = torch.from_numpy(vis).permute(2, 0, 1)    # [3,H,W]
        return ir_t, vis_t
