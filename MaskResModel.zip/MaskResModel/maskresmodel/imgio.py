# -*- coding: utf-8 -*-
"""
Filesystem image I/O shim.

This OpenCV build (opencv-python 4.10.0.84 / 5.0.0 on Windows) cannot open
files whose path contains non-ASCII characters (e.g. the Chinese project
directory), while in-memory operations work. PIL handles such paths reliably,
so ALL filesystem image I/O in this experiment suite goes through this module;
cv2 is used for in-memory transforms only (resize / cvtColor / applyColorMap /
calcHist / colormaps).
"""
import numpy as np
from PIL import Image


def imread_gray(path):
    """-> uint8 (H, W) grayscale"""
    return np.asarray(Image.open(path).convert("L"))


def imread_rgb(path):
    """-> uint8 (H, W, 3) RGB"""
    return np.asarray(Image.open(path).convert("RGB"))


def imwrite(path, arr):
    """Save uint8 array: (H,W) grayscale or (H,W,3) RGB (PIL mode RGB)."""
    arr = np.ascontiguousarray(arr)
    if arr.ndim == 3:
        Image.fromarray(arr, mode="RGB").save(path)
    else:
        Image.fromarray(arr, mode="L").save(path)
