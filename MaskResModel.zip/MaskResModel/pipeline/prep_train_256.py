# -*- coding: utf-8 -*-
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
"""
One-off preprocessing: read the 181-pair RoadScene training manifest,
resize every IR (gray) and VIS (RGB) pair to 256x256, and save them under
data/train_256/ so training does not re-resize every epoch.

Writes data/train_256_manifest.csv with columns: pair_id, ir_path, vis_path, rule.
All filesystem I/O goes through imgio (PIL) because cv2 cannot open non-ASCII
paths on this host; cv2.resize is in-memory only.
"""
import csv
import os
import sys

import cv2

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from maskresmodel.config import DATA
from maskresmodel.imgio import imread_gray, imread_rgb, imwrite

SRC_CSV = os.path.join(DATA, "roadscene_train.csv")
DST_DIR = os.path.join(DATA, "train_256")
DST_CSV = os.path.join(DATA, "train_256_manifest.csv")
IMG_SIZE = (256, 256)  # (W, H) for cv2.resize


def main():
    os.makedirs(DST_DIR, exist_ok=True)
    rows = list(csv.DictReader(open(SRC_CSV, encoding="utf-8")))
    out_rows = []
    n_ok, n_skip = 0, 0
    for r in rows:
        pid = r["pair_id"]
        ir_dst = os.path.join(DST_DIR, f"{pid}_ir.png")
        vis_dst = os.path.join(DST_DIR, f"{pid}_vis.png")
        if os.path.exists(ir_dst) and os.path.exists(vis_dst):
            n_skip += 1
        else:
            ir = imread_gray(r["ir_path"])
            vis = imread_rgb(r["vis_path"])
            ir = cv2.resize(ir, IMG_SIZE)
            vis = cv2.resize(vis, IMG_SIZE)
            imwrite(ir_dst, ir)
            imwrite(vis_dst, vis)
            n_ok += 1
        out_rows.append({
            "pair_id": pid,
            "ir_path": ir_dst,
            "vis_path": vis_dst,
            "rule": r.get("rule", ""),
        })

    with open(DST_CSV, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["pair_id", "ir_path", "vis_path", "rule"])
        w.writeheader()
        w.writerows(out_rows)

    print(f"[prep] wrote {n_ok} pairs (skipped existing {n_skip}) -> {DST_DIR}")
    print(f"[prep] manifest -> {DST_CSV} ({len(out_rows)} rows)")


if __name__ == "__main__":
    main()
