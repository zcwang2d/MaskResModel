# -*- coding: utf-8 -*-
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
"""
TNO preprocessing (PIL-based; the TNO BMPs are rejected by cv2's BMP decoder):
  1. walk scene folders, decode each image with PIL,
  2. classify IR vs VIS (filename/path rules first, channel count as fallback),
  3. pair within each leaf directory (one representative pair per scene),
  4. convert to PNG under data/tno_png/ and write data/tno.csv.

Outputs:
  data/tno_png/{pair_id}_ir.png, data/tno_png/{pair_id}_vis.png
  data/tno.csv (pair_id, ir_path, vis_path, rule)
"""
import os
import csv
import glob

import numpy as np
from PIL import Image

from maskresmodel.config import TNO_ROOT, DATA


def classify_tno(path):
    name = os.path.basename(path).lower()
    low = path.lower().replace("\\", "/")
    if name in ("ir.bmp",) or name.startswith("ir_") or name == "ir.png" \
            or "thermal" in low or "lwir" in name:
        return "IR"
    if name in ("vis.bmp",) or name.startswith("vis_") or name == "vis.png" \
            or "visual" in low or "/dhv" in low or name.startswith("dhv"):
        return "VIS"
    if "/rad" in low or name.startswith("rad"):
        return "IR"
    return None


def load_pil(path):
    im = Image.open(path)
    im.load()
    return im


def main():
    os.makedirs(os.path.join(DATA, "tno_png"), exist_ok=True)
    imgs = sorted(glob.glob(os.path.join(TNO_ROOT, "**", "*.bmp"), recursive=True))
    imgs += sorted(glob.glob(os.path.join(TNO_ROOT, "**", "*.png"), recursive=True))
    imgs += sorted(glob.glob(os.path.join(TNO_ROOT, "**", "*.jpg"), recursive=True))

    by_dir = {}
    for p in imgs:
        b = os.path.basename(p).lower()
        if b.startswith(("readme", "refrence", "reference")) or "_rg." in b \
                or b.endswith("_rg.bmp") or "refrences" in p.lower():
            continue
        by_dir.setdefault(os.path.dirname(p), []).append(p)

    rows, flags = [], []
    for d in sorted(by_dir):
        files = by_dir[d]
        irs, viss = [], []
        for p in files:
            try:
                im = load_pil(p)
            except Exception:
                continue
            channels = im.mode
            cls = classify_tno(p)
            if cls == "IR":
                irs.append((p, channels))
            elif cls == "VIS":
                viss.append((p, channels))
            else:
                if channels in ("L", "I", "F"):
                    irs.append((p, channels))
                else:
                    viss.append((p, channels))
        if len(irs) == 1 and len(viss) == 1:
            ir, vi = irs[0][0], viss[0][0]
            if irs[0][1] in ("L", "I", "F") and viss[0][1] in ("L", "I", "F"):
                flags.append((os.path.basename(ir), os.path.basename(vi), d))
            rows.append((ir, vi, "auto"))
        else:
            flags.append(("(multi)", f"ir={len(irs)} vis={len(viss)}", d))

    os.makedirs(os.path.join(DATA, "tno_png"), exist_ok=True)
    csv_rows = []
    for i, (ir, vi, rule) in enumerate(rows):
        pair = f"tno_{i:02d}"
        ir_out = os.path.join(DATA, "tno_png", f"{pair}_ir.png")
        vi_out = os.path.join(DATA, "tno_png", f"{pair}_vis.png")
        load_pil(ir).save(ir_out)
        load_pil(vi).save(vi_out)
        csv_rows.append((pair, ir_out, vi_out, rule))

    with open(os.path.join(DATA, "tno.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["pair_id", "ir_path", "vis_path", "rule"])
        w.writerows(csv_rows)

    print(f"[tno_prep] {len(csv_rows)} pairs written -> data/tno.csv")
    print(f"[tno_prep] scenes that need MANUAL review ({len(flags)}):")
    for a, b, d in flags:
        print("   FLAG:", a, "<->", b, "|", os.path.basename(d))


if __name__ == "__main__":
    main()
