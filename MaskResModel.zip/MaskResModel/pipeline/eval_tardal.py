# -*- coding: utf-8 -*-
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
"""
eval_tardal.py — TarDAL (CVPR 2022, official weights tardal++.pt) real CPU inference
on the same TNO / RoadScene manifests, same 256x256 preprocessing and the same
metric pipeline as the other five baselines.

Outputs:
  baselines/TarDAL/{tno,roadscene_test}/fused/*.png   (256x256 grayscale)
  baselines/TarDAL/{tno,roadscene_test}/metrics.csv
  baselines/TarDAL/{tno,roadscene_test}/summary.json
  metrics/baselines_summary.json  (updated with TarDAL entry)
"""
import csv
import json
import os
import sys
import time

import numpy as np
import torch
from PIL import Image

ROOT = r"C:\Users\zcwan\Desktop\多模态\IRVIS_Fusion_SCI"
TARDAL_SRC = os.path.join(ROOT, "paper_build", "img_fusion_gitee",
                          "Image-Fusion-main", "TarDAL-main")
sys.path.insert(0, TARDAL_SRC)
from modules.generator import Generator  # noqa: E402

from maskresmodel.metrics import calculate_fusion_metrics  # noqa: E402

IMG_SIZE = (256, 256)


def load_pair(ir_path, vis_path):
    ir = np.asarray(Image.open(ir_path).convert("L")).astype(np.float32) / 255.0
    vis = np.asarray(Image.open(vis_path).convert("L")).astype(np.float32) / 255.0
    ir = np.asarray(Image.fromarray((ir * 255).astype(np.uint8)).resize(IMG_SIZE)).astype(np.float32) / 255.0
    vis = np.asarray(Image.fromarray((vis * 255).astype(np.uint8)).resize(IMG_SIZE)).astype(np.float32) / 255.0
    ir_t = torch.from_numpy(ir).unsqueeze(0).unsqueeze(0)
    vi_t = torch.from_numpy(vis).unsqueeze(0).unsqueeze(0)
    return ir_t, vi_t


def main():
    weights = os.path.join(ROOT, "paper_build", "tardal_dt_official.pth")
    if not os.path.exists(weights):
        weights = os.path.join(TARDAL_SRC, "weights", "tardal++.pt")
    net = Generator(dim=32, depth=3)
    ck = torch.load(weights, map_location="cpu", weights_only=True)
    if isinstance(ck, dict) and "g" in ck:
        net.load_state_dict(ck["g"])
    else:
        # official state_dict carries a 'use_eval' marker; it is not a network
        # parameter, so load with strict=False and honour its eval/train choice.
        use_eval = ck.get("use_eval", True) if isinstance(ck, dict) else True
        net.load_state_dict(ck, strict=False)
        if use_eval:
            net.eval()
        else:
            net.train()

    torch.set_num_threads(12)
    n_params = sum(p.numel() for p in net.parameters()) / 1e6

    # FLOPs (fvcore, same tooling as efficiency.py)
    flops = None
    try:
        from fvcore.nn import FlopCountAnalysis
        irf = torch.randn(1, 1, 256, 256)
        vif = torch.randn(1, 1, 256, 256)
        flops = FlopCountAnalysis(net, (irf, vif)).total() / 1e9
    except Exception as e:  # noqa
        print(f"[tardal] FlopCountAnalysis failed: {e}")

    print(f"[tardal] weights={os.path.basename(weights)} use_eval={ck.get('use_eval', True) if isinstance(ck, dict) else True} params_M={n_params:.4f} "
          f"flops_G={None if flops is None else round(flops, 4)}")

    for ds, manifest in [("tno", os.path.join(ROOT, "data", "tno.csv")),
                         ("roadscene_test", os.path.join(ROOT, "data", "roadscene_test.csv"))]:
        out_dir = os.path.join(ROOT, "baselines", "TarDAL", ds)
        fus_dir = os.path.join(out_dir, "fused")
        os.makedirs(fus_dir, exist_ok=True)
        with open(manifest, encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        results, timings = [], []
        with torch.no_grad():
            for i, r in enumerate(rows):
                ir_t, vi_t = load_pair(r["ir_path"], r["vis_path"])
                t0 = time.perf_counter()
                fus = net(ir_t, vi_t).clip(0.0, 1.0)
                timings.append(time.perf_counter() - t0)
                f_np = (fus.squeeze().cpu().numpy() * 255.0).astype(np.uint8)
                # reference sources at 256 (same as eval_fusion.py)
                vis_rgb = np.asarray(Image.open(r["vis_path"]).convert("RGB").resize(IMG_SIZE))
                ir_ori = np.asarray(Image.open(r["ir_path"]).convert("L").resize(IMG_SIZE))
                met = calculate_fusion_metrics(f_np, vis_rgb, ir_ori)
                Image.fromarray(f_np).save(os.path.join(fus_dir, f"{r['pair_id']}.png"))
                results.append({"pair_id": r["pair_id"], **met})
                if i % 10 == 0:
                    print(f"[tardal] {ds} {i + 1}/{len(rows)} {r['pair_id']} EN {met['EN']}")
        keys = ["EN", "SD", "SF", "SSIM_VIS", "SSIM_IR", "MI"]
        means = {k: round(float(np.mean([x[k] for x in results])), 4) for k in keys}
        t_ms = np.array(timings) * 1000.0
        with open(os.path.join(out_dir, "metrics.csv"), "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=["pair_id"] + keys + ["MI_VIS", "MI_IR"])
            w.writeheader()
            w.writerows(results)
        summary = {
            "method": "TarDAL", "dataset": ds, "n_pairs": len(results),
            "size": list(IMG_SIZE),
            "metrics_mean": means,
            "time_ms_mean": round(float(np.mean(t_ms)), 3),
            "time_ms_std": round(float(np.std(t_ms)), 3),
        }
        with open(os.path.join(out_dir, "summary.json"), "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)
        print(f"[tardal] {ds}: means={means} time={summary['time_ms_mean']} ms")

    # ---- update metrics/baselines_summary.json with TarDAL ----
    bsum_path = os.path.join(ROOT, "metrics", "baselines_summary.json")
    with open(bsum_path, encoding="utf-8") as f:
        bsum = json.load(f)
    bsum["methods"]["TarDAL"] = {
        "category": "deep", "params_M": round(n_params, 4),
        "flops_G": round(flops, 4) if flops else None,
        "time_ms": {},
        "metrics": {},
    }
    for ds in ["tno", "roadscene_test"]:
        with open(os.path.join(ROOT, "baselines", "TarDAL", ds, "summary.json"), encoding="utf-8") as f:
            s = json.load(f)
        bsum["methods"]["TarDAL"]["time_ms"][ds] = {"mean": s["time_ms_mean"], "std": s["time_ms_std"]}
        bsum["methods"]["TarDAL"]["metrics"][ds] = s["metrics_mean"]
    with open(bsum_path, "w", encoding="utf-8") as f:
        json.dump(bsum, f, indent=2, ensure_ascii=False)
    print("[tardal] baselines_summary.json updated (TarDAL added)")
    print("[tardal] ALL_DONE")


if __name__ == "__main__":
    main()
