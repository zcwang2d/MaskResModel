# -*- coding: utf-8 -*-
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
"""
Build train/test manifests:
  - RoadScene: 221 IR / 222 VIS (name-intersection -> 221 pairs), seed-42 split
    181 train / 40 test
  - TNO: automatic IR/VIS pairing over the 5 scene folders (channel-based
    detection first, filename/path rules as fallback); all usable pairs -> test
Outputs (CSV, header pair_id,ir_path,vis_path,rule):
  data/roadscene_train.csv, data/roadscene_test.csv, data/tno.csv
"""
import os
import csv
import random
import glob

import cv2
import numpy as np

from maskresmodel.config import TNO_ROOT, ROAD_IR, ROAD_VIS, DATA, SEED, ROAD_TRAIN_N


def write_csv(path, rows):
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["pair_id", "ir_path", "vis_path", "rule"])
        w.writerows(rows)
    print(f"[data_prep] wrote {len(rows)} rows -> {path}")


# ---------------------------------------------------------------- RoadScene
def build_roadscene():
    ir_files = {os.path.splitext(f)[0]: os.path.join(ROAD_IR, f)
                for f in os.listdir(ROAD_IR) if f.lower().endswith((".png", ".jpg"))}
    vis_files = {os.path.splitext(f)[0]: os.path.join(ROAD_VIS, f)
                 for f in os.listdir(ROAD_VIS) if f.lower().endswith((".png", ".jpg"))}
    common = sorted(set(ir_files) & set(vis_files))
    random.Random(SEED).shuffle(common)
    train = common[:ROAD_TRAIN_N]
    test = common[ROAD_TRAIN_N:]
    write_csv(os.path.join(DATA, "roadscene_train.csv"),
              [(f, ir_files[f], vis_files[f], "name") for f in train])
    write_csv(os.path.join(DATA, "roadscene_test.csv"),
              [(f, ir_files[f], vis_files[f], "name") for f in test])
    print(f"[data_prep] RoadScene: {len(common)} common pairs "
          f"({len(train)} train / {len(test)} test)")


# -------------------------------------------------------------------- TNO
def classify_tno(path):
    """Return ('IR'|'VIS'|None) for a TNO image file given its path+name."""
    name = os.path.basename(path).lower()
    low = path.lower().replace("\\", "/")
    if name in ("ir.bmp", "ir.jpg", "ir.png") or name.startswith("ir_") or "thermal" in low:
        return "IR"
    if name in ("vis.bmp", "vis.jpg", "vis.png") or name.startswith("vis_") or "visual" in low:
        return "VIS"
    if "/dhv" in low or name.startswith("dhv"):
        return "VIS"
    if "/rad" in low or name.startswith("rad"):
        return "IR"
    return None


def is_gray(path):
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    if img is None:
        return None
    return img.shape[2] == 1


def build_tno():
    bmps = sorted(glob.glob(os.path.join(TNO_ROOT, "**", "*.bmp"), recursive=True))
    bmps += sorted(glob.glob(os.path.join(TNO_ROOT, "**", "*.png"), recursive=True))
    bmps += sorted(glob.glob(os.path.join(TNO_ROOT, "**", "*.jpg"), recursive=True))

    # group by leaf directory
    by_dir = {}
    for p in bmps:
        b = os.path.basename(p).lower()
        if b.startswith(("readme", "refrence", "reference")) or "_rg." in b or b.endswith("_rg.bmp"):
            continue  # reference / documentation files
        d = os.path.dirname(p)
        by_dir.setdefault(d, []).append(p)

    pairs, flagged = [], []
    for d in sorted(by_dir):
        files = by_dir[d]
        irs, viss = [], []
        for p in files:
            g = is_gray(p)
            if g is None:
                continue
            cls = classify_tno(p)
            if cls == "IR":
                irs.append(p)
            elif cls == "VIS":
                viss.append(p)
            else:
                # channel-based fallback: single channel -> IR, color -> VIS
                (irs if g else viss).append(p)
        for ir in sorted(irs):
            for vi in sorted(viss):
                pairs.append((ir, vi))
                if len(irs) > 1 or len(viss) > 1:
                    flagged.append((ir, vi))
                if is_gray(ir) and is_gray(vi):
                    flagged.append((ir, vi))  # gray-gray pair: manual check

    write_csv(os.path.join(DATA, "tno.csv"),
              [(f"tno_{i:02d}", ir, vi, "auto") for i, (ir, vi) in enumerate(pairs)])
    print(f"[data_prep] TNO: {len(pairs)} candidate pairs; {len(flagged)} flagged for manual check:")
    for ir, vi in flagged[:40]:
        print("   FLAG:", os.path.basename(ir), "<->", os.path.basename(vi))


if __name__ == "__main__":
    os.makedirs(DATA, exist_ok=True)
    build_roadscene()
    build_tno()
