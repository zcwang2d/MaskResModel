# -*- coding: utf-8 -*-
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
"""
Efficiency statistics: parameters, FLOPs (fvcore), CPU inference time.

Usage:
  python efficiency.py --ablation full --weights ../runs/full/checkpoints/model_best.pth \
      --out ../metrics/efficiency.csv
"""
import argparse
import csv
import json
import os
import time

import numpy as np
import torch

from maskresmodel.model import MaskResModel


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ablation", default="full")
    ap.add_argument("--weights", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--threads", type=int, default=12)
    args = ap.parse_args()

    torch.set_num_threads(args.threads)
    model = MaskResModel(args.ablation)
    if args.weights and os.path.exists(args.weights):
        model.load_state_dict(torch.load(args.weights, map_location="cpu"))
    model.eval()

    params = sum(p.numel() for p in model.parameters()) / 1e6

    try:
        from fvcore.nn import FlopCountAnalysis
        ir = torch.randn(1, 1, 256, 256)
        vis = torch.randn(1, 3, 256, 256)
        flops = FlopCountAnalysis(model, (ir, vis)).total() / 1e9
    except Exception as e:  # noqa
        flops = None
        print(f"[eff] FlopCountAnalysis failed: {e}")

    with torch.no_grad():
        ir = torch.randn(1, 1, 256, 256)
        vis = torch.randn(1, 3, 256, 256)
        for _ in range(5):
            model(ir, vis)  # warmup
        ts = []
        for _ in range(50):
            t0 = time.perf_counter()
            model(ir, vis)
            ts.append(time.perf_counter() - t0)
    time_ms = float(np.mean(ts)) * 1000
    time_std = float(np.std(ts)) * 1000

    row = {"method": f"Ours-{args.ablation}", "params_M": round(params, 4),
           "flops_G": round(flops, 4) if flops else None,
           "time_ms": round(time_ms, 3), "time_std_ms": round(time_std, 3)}

    if args.out:
        os.makedirs(os.path.dirname(args.out), exist_ok=True)
        new = not os.path.exists(args.out)
        with open(args.out, "a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(row.keys()))
            if new:
                w.writeheader()
            w.writerow(row)
        print(f"[eff] appended -> {args.out}")
    print("[eff]", json.dumps(row))


if __name__ == "__main__":
    main()
