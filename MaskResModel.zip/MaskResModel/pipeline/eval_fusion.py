# -*- coding: utf-8 -*-
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
"""
Inference + metrics for the proposed method on a test manifest.

Usage:
  python eval_fusion.py --run ../runs/full --manifest ../data/tno.csv \
      --out ../results/proposed/tno --threads 12
  python eval_fusion.py --run ../runs/full --manifest ../data/roadscene_test.csv \
      --out ../results/proposed/roadscene_test --threads 12
Writes: fused/*.png, metrics.csv (per pair), summary.json (means + timing).
All filesystem I/O through imgio (PIL) because cv2 cannot open non-ASCII paths.
"""
import argparse
import csv
import json
import os
import time

import cv2
import numpy as np
import torch

from maskresmodel.config import IMG_SIZE
from maskresmodel.model import MaskResModel
from maskresmodel.metrics import calculate_fusion_metrics
from maskresmodel.imgio import imread_gray, imread_rgb, imwrite


def preprocess(ir_path, vis_path):
    ir = imread_gray(ir_path)
    vis = imread_rgb(vis_path)
    ir = cv2.resize(ir, IMG_SIZE)
    vis = cv2.resize(vis, IMG_SIZE)
    ir_t = torch.from_numpy((ir / 255.0).astype(np.float32)).unsqueeze(0).unsqueeze(0)
    vis_t = torch.from_numpy((vis / 255.0).astype(np.float32)).permute(2, 0, 1).unsqueeze(0)
    return ir_t, vis_t


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--threads", type=int, default=12)
    ap.add_argument("--save-mask", action="store_true",
                    help="also save mask/residual heatmaps (proposed method only)")
    args = ap.parse_args()

    torch.set_num_threads(args.threads)
    os.makedirs(os.path.join(args.out, "fused"), exist_ok=True)

    with open(os.path.join(args.run, "summary.json"), encoding="utf-8") as f:
        cfg = json.load(f)
    ablation = cfg["ablation"]
    model = MaskResModel(ablation)
    model.load_state_dict(torch.load(os.path.join(args.run, "checkpoints", "model_best.pth"),
                                     map_location="cpu"))
    model.eval()
    print(f"[eval] model {ablation} loaded from {args.run}")

    rows = list(csv.DictReader(open(args.manifest, encoding="utf-8")))
    timing = []
    results = []
    with torch.no_grad():
        for i, r in enumerate(rows):
            ir_t, vis_t = preprocess(r["ir_path"], r["vis_path"])
            t0 = time.perf_counter()
            fused, mask, res = model(ir_t, vis_t)
            timing.append(time.perf_counter() - t0)

            f_np = fused.squeeze(0).permute(1, 2, 0).cpu().numpy()
            f_u8 = (np.clip(f_np, 0, 1) * 255).astype(np.uint8)
            imwrite(os.path.join(args.out, "fused", f"{r['pair_id']}.png"), f_u8)

            if args.save_mask:
                m = mask.squeeze().cpu().numpy()
                mm_bgr = cv2.applyColorMap((np.clip(m, 0, 1) * 255).astype(np.uint8),
                                           cv2.COLORMAP_JET)
                imwrite(os.path.join(args.out, "fused", f"{r['pair_id']}_mask.png"),
                        cv2.cvtColor(mm_bgr, cv2.COLOR_BGR2RGB))
                rn = res.squeeze(0).permute(1, 2, 0).cpu().numpy()
                rn = (rn - rn.min()) / (rn.max() - rn.min() + 1e-8)
                rh_bgr = cv2.applyColorMap((rn * 255).astype(np.uint8), cv2.COLORMAP_JET)
                imwrite(os.path.join(args.out, "fused", f"{r['pair_id']}_res.png"),
                        cv2.cvtColor(rh_bgr, cv2.COLOR_BGR2RGB))

            vis_rgb = cv2.resize(imread_rgb(r["vis_path"]), IMG_SIZE)
            ir_ori = cv2.resize(imread_gray(r["ir_path"]), IMG_SIZE)
            met = calculate_fusion_metrics(f_u8, vis_rgb, ir_ori)
            results.append({"pair_id": r["pair_id"], **met})
            if i % 20 == 0:
                print(f"[eval] {i}/{len(rows)} {r['pair_id']} EN {met['EN']} SD {met['SD']}")

    with open(os.path.join(args.out, "metrics.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(results[0].keys()))
        w.writeheader()
        w.writerows(results)

    keys = ["EN", "SD", "SF", "SSIM_VIS", "SSIM_IR", "MI"]
    means = {k: round(float(np.mean([x[k] for x in results])), 4) for k in keys}
    summary = {
        "run": args.run, "manifest": args.manifest, "n_pairs": len(results),
        "means": means,
        "inference_ms_mean": round(float(np.mean(timing)) * 1000, 3),
        "inference_ms_std": round(float(np.std(timing)) * 1000, 3),
    }
    with open(os.path.join(args.out, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(f"[eval] DONE -> {args.out}")
    print(f"[eval] means: {means}")
    print(f"[eval] inference {summary['inference_ms_mean']} +- "
          f"{summary['inference_ms_std']} ms/image (CPU)")


if __name__ == "__main__":
    main()
