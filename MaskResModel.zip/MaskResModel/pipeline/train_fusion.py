# -*- coding: utf-8 -*-
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
"""
Training entry for MaskResModel (CPU). One process per run; do not run two
instances concurrently on the same machine (they share CPU threads).

Usage:
  python train_fusion.py --ablation full --lr 1e-4 --epochs 150 \
      --out ../runs/full --threads 12
  python train_fusion.py --ablation no_afhs --out ../runs/ablate_no_afhs ...
  (--resume resumes from <out>/checkpoints/model_last.pth + <out>/state.json)
"""
import argparse
import json
import os
import random
import time

import cv2
import numpy as np
import torch
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import CosineAnnealingLR

from maskresmodel.config import DATA, RUNS
from maskresmodel.model import MaskResModel
from maskresmodel.loss import MaskResLoss
from maskresmodel.dataset import IRVISDataset
from maskresmodel.imgio import imwrite


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def make_viz(ir, vis, mask, res, fused, path):
    """Save a montage (IR, VIS, mask heatmap, residual heatmap, fused) in RGB."""
    def to_uint(x):
        return np.clip((x * 255), 0, 255).astype(np.uint8)

    ir_g = ir[0, 0].detach().cpu().numpy()
    vis_rgb = vis[0].permute(1, 2, 0).detach().cpu().numpy()
    m = mask[0, 0].detach().cpu().numpy()
    r = res[0].permute(1, 2, 0).detach().cpu().numpy()
    f = fused[0].permute(1, 2, 0).detach().cpu().numpy()

    ir3 = cv2.cvtColor(to_uint(ir_g), cv2.COLOR_GRAY2RGB)
    mask_hm = cv2.cvtColor(cv2.applyColorMap(to_uint(m), cv2.COLORMAP_JET),
                           cv2.COLOR_BGR2RGB)
    r_norm = (r - r.min()) / (r.max() - r.min() + 1e-8)
    res_hm = cv2.cvtColor(cv2.applyColorMap(to_uint(r_norm), cv2.COLORMAP_JET),
                          cv2.COLOR_BGR2RGB)
    row = np.hstack([ir3, to_uint(vis_rgb), mask_hm, res_hm, to_uint(f)])
    imwrite(path, row)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ablation", default="full",
                    choices=["full", "no_afhs", "no_rcm", "no_ltsm", "no_multi"])
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--epochs", type=int, default=150)
    ap.add_argument("--batch", type=int, default=10)
    ap.add_argument("--threads", type=int, default=12)
    ap.add_argument("--out", required=True)
    ap.add_argument("--train-csv", default=os.path.join(DATA, "roadscene_train.csv"))
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--viz-every", type=int, default=25)
    args = ap.parse_args()

    torch.set_num_threads(args.threads)
    set_seed(42)

    out = args.out
    ckpt_dir = os.path.join(out, "checkpoints")
    viz_dir = os.path.join(out, "viz")
    os.makedirs(ckpt_dir, exist_ok=True)
    os.makedirs(viz_dir, exist_ok=True)

    train_csv = args.train_csv
    model = MaskResModel(args.ablation)
    criterion = MaskResLoss(args.ablation)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    scheduler = CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=1e-6)
    loader = DataLoader(IRVISDataset(train_csv, augment=True),
                        batch_size=args.batch, shuffle=True, num_workers=0)

    start_epoch = 0
    if args.resume:
        model.load_state_dict(torch.load(os.path.join(ckpt_dir, "model_last.pth"),
                                         map_location="cpu"))
        if os.path.exists(os.path.join(out, "state.json")):
            with open(os.path.join(out, "state.json")) as f:
                st = json.load(f)
            start_epoch = st["epoch"] + 1
            opt_pt = os.path.join(out, "optimizer_last.pt")
            if os.path.exists(opt_pt):
                optimizer.load_state_dict(torch.load(opt_pt, map_location="cpu"))
            print(f"[train] resumed from epoch {st['epoch']}")

    log_path = os.path.join(out, "train_log.jsonl")
    logf = open(log_path, "a", encoding="utf-8")
    best_loss = float("inf")
    t_start = time.time()

    for epoch in range(start_epoch, args.epochs):
        model.train()
        s = {"mask": 0.0, "res": 0.0, "bg": 0.0, "range": 0.0, "rres": 0.0}
        total = 0.0
        for ir, vis in loader:
            fused, mask, res = model(ir, vis)
            loss, lm, lr_, lb, rr, rre = criterion(ir, vis, mask, res, fused)
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 0.5)
            optimizer.step()
            total += loss.item()
            s["mask"] += lm.item(); s["res"] += lr_.item(); s["bg"] += lb.item()
            s["range"] += rr.item(); s["rres"] += rre.item()
        scheduler.step()

        n = len(loader)
        rec = {"epoch": epoch, "loss": round(total / n, 6),
               "loss_mask": round(s["mask"] / n, 6), "loss_res": round(s["res"] / n, 6),
               "loss_bg": round(s["bg"] / n, 6), "reg_range": round(s["range"] / n, 6),
               "reg_res": round(s["rres"] / n, 6), "lr": optimizer.param_groups[0]["lr"],
               "elapsed_sec": round(time.time() - t_start, 1)}
        logf.write(json.dumps(rec) + "\n")
        logf.flush()
        print(f"[train] ep {epoch:03d} loss {rec['loss']:.5f} "
              f"(mask {rec['loss_mask']:.5f} res {rec['loss_res']:.5f} "
              f"bg {rec['loss_bg']:.5f} range {rec['reg_range']:.5f} rres {rec['reg_res']:.5f})")

        torch.save(model.state_dict(), os.path.join(ckpt_dir, "model_last.pth"))
        if rec["loss"] < best_loss:
            best_loss = rec["loss"]
            torch.save(model.state_dict(), os.path.join(ckpt_dir, "model_best.pth"))
            with open(os.path.join(out, "best.json"), "w") as f:
                json.dump({"epoch": epoch, "loss": rec["loss"]}, f)
        if epoch % args.viz_every == 0 or epoch == args.epochs - 1:
            model.eval()
            with torch.no_grad():
                ir, vis = next(iter(loader))
                fused, mask, res = model(ir[:1], vis[:1])
                make_viz(ir[:1], vis[:1], mask, res, fused,
                         os.path.join(viz_dir, f"epoch_{epoch:04d}.png"))
            model.train()
        torch.save(optimizer.state_dict(),
                   os.path.join(out, "optimizer_last.pt"))
        with open(os.path.join(out, "state.json"), "w") as f:
            json.dump({"epoch": epoch}, f)

    logf.close()

    with torch.no_grad():
        model.eval()
        ir, vis = next(iter(DataLoader(IRVISDataset(train_csv), batch_size=1)))
        fused, mask, res = model(ir, vis)
    summary = {
        "ablation": args.ablation, "epochs": args.epochs, "lr": args.lr,
        "batch": args.batch, "seed": 42, "threads": args.threads,
        "train_csv": train_csv, "augment": True, "img_size": "256x256",
        "device": "cpu", "best_epoch": best_epoch_of(best_loss, log_path),
        "best_loss": best_loss, "final_loss": rec["loss"],
        "res_w_raw": float(model.res_w.item()), "res_w_used": float(torch.sigmoid(model.res_w).item()),
        "ir_w_raw": float(model.ir_w.item()), "ir_w_used": float(torch.sigmoid(model.ir_w).item()),
        "theta_raw": float(model.theta.item()),
        "theta_tau": float(torch.sigmoid(model.theta).item() * 0.2 + 0.75),
        "elapsed_sec": round(time.time() - t_start, 1),
    }
    with open(os.path.join(out, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(f"[train] DONE -> {out} | summary.json written")


def best_epoch_of(best_loss, log_path):
    best_ep = None
    if os.path.exists(log_path):
        for line in open(log_path, encoding="utf-8"):
            r = json.loads(line)
            if r["loss"] <= best_loss:
                best_ep = r["epoch"]
    return best_ep


if __name__ == "__main__":
    main()
