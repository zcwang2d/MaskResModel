# -*- coding: utf-8 -*-
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
"""Quick learning-rate sanity probe: 8 epochs per candidate lr on the train set.

Usage: python probe.py --threads 12  -> prints per-lr average losses.
"""
import argparse
import os
import random

import numpy as np
import torch
from torch.utils.data import DataLoader

from maskresmodel.config import DATA
from maskresmodel.model import MaskResModel
from maskresmodel.loss import MaskResLoss
from maskresmodel.dataset import IRVISDataset


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--threads", type=int, default=12)
    ap.add_argument("--epochs", type=int, default=8)
    ap.add_argument("--lrs", default="5e-6,5e-5,1e-4,2e-4,5e-4")
    args = ap.parse_args()
    torch.set_num_threads(args.threads)
    set_seed(42)

    loader = DataLoader(IRVISDataset(os.path.join(DATA, "roadscene_train.csv"), augment=True),
                        batch_size=10, shuffle=True, num_workers=0)
    for lr_s in args.lrs.split(","):
        lr = float(lr_s)
        model = MaskResModel("full")
        crit = MaskResLoss("full")
        opt = torch.optim.Adam(model.parameters(), lr=lr)
        losses = []
        for ep in range(args.epochs):
            model.train()
            tot = 0.0
            for ir, vis in loader:
                fused, mask, res = model(ir, vis)
                loss, *_ = crit(ir, vis, mask, res, fused)
                opt.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 0.5)
                opt.step()
                tot += loss.item()
            avg = tot / len(loader)
            losses.append(round(avg, 5))
            print(f"[probe] lr {lr:.1e} ep {ep:02d} loss {avg:.5f}")
        print(f"[probe] lr {lr:.1e} FINAL {losses[-1]}  min {min(losses)}")


if __name__ == "__main__":
    main()
