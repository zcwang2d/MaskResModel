# -*- coding: utf-8 -*-
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
"""
Curated TNO test-set manifest.

TNO raw files use irregular naming across vendors; instead of fragile heuristics
we list every (IR, VIS) pair explicitly (scene folder + file names), verified
manually. Sequences with near-duplicate frames (DHV Fire_sequence) and pairs
whose modality cannot be determined from naming (Athena APC_2 "1_fk/2_fk")
are excluded; the selection is documented in the paper.

Outputs: data/tno_png/{pair_id}_ir.png, _vis.png  and  data/tno.csv
"""
import os
import csv
from PIL import Image

from maskresmodel.config import TNO_ROOT, DATA

# (subdir, ir_file, vis_file)
PAIRS = [
    # --- Athena (19) -------------------------------------------------------
    ("Athena_images/2_men_in_front_of_house", "IR_meting003_g.bmp", "VIS_meting003_r.bmp"),
    ("Athena_images/airplane_in_trees", "ir.bmp", "vis.bmp"),
    ("Athena_images/APC_1/view_1", "IR_fk_06_005.bmp", "VIS_fk_06_005.bmp"),
    ("Athena_images/APC_1/view_2", "IR_fk_ref_01_005.bmp", "VIS_fk_ref_01_005.bmp"),
    ("Athena_images/APC_1/view_3", "IR_fk_ref_02_005.bmp", "VIS_fk_ref_02_005.bmp"),
    ("Athena_images/APC_3/view_1", "IR_fk_bar_06_005.bmp", "VIS_fk_bar_06_005.bmp"),
    ("Athena_images/APC_3/view_2", "IR_fk_NL_01_005.bmp", "VIS_fk_NL_01_005.bmp"),
    ("Athena_images/APC_3/view_3", "IR_fk_NL_05_005.bmp", "VIS_fk_NL_05_005.bmp"),
    ("Athena_images/APC_4", "IR_fennek01_005.bmp", "VIS_fennek01_005.bmp"),
    ("Athena_images/bunker", "IR_bunker_g.bmp", "VIS_bunker-rg.bmp"),
    ("Athena_images/heather", "IR_hei_vis_g.bmp", "VIS_hei_vis_r.bmp"),
    ("Athena_images/helicopter", "IR_helib_011.bmp", "VIS_helib_011.bmp"),
    ("Athena_images/lake", "IR_lake_g.bmp", "VIS_lake_r.bmp"),
    ("Athena_images/man_in_doorway", "IR_maninhuis_g.bmp", "VIS_maninhuis_r.bmp"),
    ("Athena_images/soldier_behind_smoke_1", "IR_meting012-1200_g.bmp", "VIS_meting012-1200_r.bmp"),
    ("Athena_images/soldier_behind_smoke_2", "IR_meting012-1500_g.bmp", "VIS_meting012-1500_r.bmp"),
    ("Athena_images/soldier_behind_smoke_3", "IR_meting012-1700_g.bmp", "VIS_meting012-1700_r.bmp"),
    ("Athena_images/soldier_in_trench_1", "IR_meting016_g.bmp", "VIS_meting016_r.bmp"),
    ("Athena_images/soldier_in_trench_2", "IR_meting055_g.bmp", "VIS_meting055_r.bmp"),
    # --- DHV (3) ------------------------------------------------------------
    ("DHV_images/bench", "IR_37rad.bmp", "VIS_37dhvR.bmp"),
    ("DHV_images/sandpath", "IR_18rad.bmp", "VIS_18dhvR.bmp"),
    ("DHV_images/wall", "IR_163rad.bmp", "VIS_163dhvR.BMP"),
    # --- FEL sequences: one representative frame each (3) -------------------
    ("FEL_images/Duine_sequence/thermal", "7400i.bmp", "FEL_images/Duine_sequence/visual/7400v.bmp"),
    ("FEL_images/Nato_camp_sequence/thermal", "1800i.bmp", "FEL_images/Nato_camp_sequence/visual/1800v.bmp"),
    ("FEL_images/Tree_sequence/thermal", "4900i.bmp", "FEL_images/Tree_sequence/visual/4900v.bmp"),
    # --- Triclobs (29) ------------------------------------------------------
    ("Triclobs_images/Balls", "NIR.bmp", "VIS.bmp"),
    ("Triclobs_images/Bosnia", "LWIR_B.bmp", "VIS_R.bmp"),
    ("Triclobs_images/Farm", "Farm_IR.bmp", "Farm_Vis.bmp"),
    ("Triclobs_images/House", "NIR.bmp", "VIS.bmp"),
    ("Triclobs_images/Kaptein_01", "IR01.bmp", "Vis01.bmp"),
    ("Triclobs_images/Kaptein_1123", "Kaptein_1123_IR.bmp", "Kaptein_1123_Vis.bmp"),
    ("Triclobs_images/Kaptein_1654", "Kaptein_1654_IR.bmp", "Kaptein_1654_Vis.bmp"),
    ("Triclobs_images/Kaptein_19", "IR19.bmp", "Vis19.bmp"),
    ("Triclobs_images/Marne_01", "Marne_01_IR.bmp", "Marne_01_Vis.bmp"),
    ("Triclobs_images/Marne_02", "Marne_02_IR.bmp", "Marne_02_Vis.bmp"),
    ("Triclobs_images/Marne_03", "Marne_03_IR.bmp", "Marne_03_Vis.bmp"),
    ("Triclobs_images/Marne_04", "Marne_04_IR.bmp", "Marne_04_Vis.bmp"),
    ("Triclobs_images/Marne_06", "Marne_06_IR.bmp", "Marne_06_Vis.bmp"),
    ("Triclobs_images/Marne_07", "Marne_07_IR.bmp", "Marne_07_Vis.bmp"),
    ("Triclobs_images/Marne_09", "Marne_09_IR.bmp", "Marne_09_Vis.bmp"),
    ("Triclobs_images/Marne_11", "Marne_11_IR.bmp", "Marne_11_Vis.bmp"),
    ("Triclobs_images/Marne_15", "Marne_15_IR.bmp", "Marne_15_Vis.bmp"),
    ("Triclobs_images/Marne_24", "Marne_24_IR.bmp", "Marne_24_Vis.bmp"),
    ("Triclobs_images/Movie_01", "Movie_01_IR.bmp", "Movie_01_Vis.bmp"),
    ("Triclobs_images/Movie_12", "Movie_12_IR.bmp", "Movie_12_Vis.bmp"),
    ("Triclobs_images/Movie_14", "Movie_14_IR.bmp", "Movie_14_Vis.bmp"),
    ("Triclobs_images/Movie_18", "Movie_18_IR.bmp", "Movie_18_Vis.bmp"),
    ("Triclobs_images/Movie_24", "Movie_24_IR.bmp", "Movie_24_Vis.bmp"),
    ("Triclobs_images/Reek", "Reek_IR.bmp", "Reek_Vis.bmp"),
    ("Triclobs_images/soldiers_with_jeep", "Jeep_IR.bmp", "Jeep_Vis.bmp"),
    ("Triclobs_images/square_with_houses", "LWIR.bmp", "VIS.bmp"),
    ("Triclobs_images/houses_with_3_men", "LWIR.bmp", "VIS.bmp"),
    ("Triclobs_images/jeep_in_smoke", "LWIR_B.bmp", "VIS_R.bmp"),
    ("Triclobs_images/Veluwe", "NIR.bmp", "VIS.bmp"),
]


def resolve(sub, name):
    if os.path.sep in name or "/" in name:
        return os.path.join(TNO_ROOT, name)
    return os.path.join(TNO_ROOT, sub, name)


def pair_id(sub):
    base = os.path.basename(sub).lower().replace(" ", "_")
    scene = sub.split("/")[-1]
    if scene.startswith("view_"):
        parent = os.path.basename(sub.split("/")[-2])
        return f"tno_{parent}_{scene}"
    if "sequence" in sub:
        seq = sub.split("/")[-2].replace("_sequence", "")
        return f"tno_{seq}"
    return f"tno_{scene}"


def main():
    os.makedirs(os.path.join(DATA, "tno_png"), exist_ok=True)
    rows = []
    for sub, ir, vis in PAIRS:
        ir_p, vis_p = resolve(sub, ir), resolve(sub, vis)
        pid = pair_id(sub)
        ir_out = os.path.join(DATA, "tno_png", f"{pid}_ir.png")
        vis_out = os.path.join(DATA, "tno_png", f"{pid}_vis.png")
        Image.open(ir_p).save(ir_out)
        Image.open(vis_p).save(vis_out)
        rows.append((pid, ir_out, vis_out, "curated"))

    with open(os.path.join(DATA, "tno.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["pair_id", "ir_path", "vis_path", "rule"])
        w.writerows(rows)
    print(f"[tno_curate] {len(rows)} curated pairs -> data/tno.csv")


if __name__ == "__main__":
    main()
