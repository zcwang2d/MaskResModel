# -*- coding: utf-8 -*-
"""YOLOv8n (COCO pretrained, ONNX) detection over RoadScene test fused results.
Records per-image detection counts at several conf thresholds + mean conf.
Checkpointed JSONL so reruns skip completed (image, method) pairs.
"""
import csv, json, os, sys
import numpy as np
import cv2
import onnxruntime as ort

ROOT = r"C:\Users\zcwan\Desktop\多模态\IRVIS_Fusion_SCI"
CSV_PATH = os.path.join(ROOT, "data", "roadscene_test.csv")
MODEL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "yolov8n.onnx")
OUT_JSONL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "detections.jsonl")
HERE = os.path.dirname(os.path.abspath(__file__))
ANN_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ann")
os.makedirs(ANN_DIR, exist_ok=True)

def get_path(m, pid, ir_vis):
    if m == "IR":
        return ir_vis[pid][0]
    if m == "VIS":
        return ir_vis[pid][1]
    base = {
        "DWT": os.path.join(HERE, "color_fused", "DWT"),
        "GTF": os.path.join(HERE, "color_fused", "GTF"),
        "DenseFuse": os.path.join(HERE, "color_fused", "DenseFuse"),
        "RFN-Nest": os.path.join(HERE, "color_fused", "RFN-Nest"),
        "FusionGAN": os.path.join(HERE, "color_fused", "FusionGAN"),
        "TarDAL": os.path.join(HERE, "color_fused", "TarDAL"),
        "Ours": os.path.join(ROOT, "results", "proposed", "full", "roadscene_test", "fused"),
    }[m]
    return os.path.join(base, pid + ".png")

ORDER = ["IR", "VIS", "DWT", "GTF", "DenseFuse", "RFN-Nest", "FusionGAN", "TarDAL", "Ours"]
CONF_THRESHOLDS = [0.15, 0.25, 0.35]
NMS_IOU = 0.45
MAIN_CONF = 0.25  # threshold for mean-conf stats / annotations

COCO_PERSON = 0
COCO_VEHICLES = {1: "bicycle", 2: "car", 3: "motorcycle", 5: "bus", 7: "truck"}

def letterbox(img, new=640):
    h, w = img.shape[:2]
    r = min(new / h, new / w)
    nh, nw = int(round(h * r)), int(round(w * r))
    resized = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_LINEAR)
    top = (new - nh) // 2
    bottom = new - nh - top
    left = (new - nw) // 2
    right = new - nw - left
    padded = cv2.copyMakeBorder(resized, top, bottom, left, right,
                                cv2.BORDER_CONSTANT, value=(114, 114, 114))
    return padded, r, left, top

def preprocess(path):
    img = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(path)
    pad, r, left, top = letterbox(img)
    blob = pad[:, :, ::-1].transpose(2, 0, 1)[None].astype(np.float32) / 255.0
    return img, blob, r, left, top

def iou(a, b):
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    iw, ih = max(0, ix2 - ix1), max(0, iy2 - iy1)
    inter = iw * ih
    return inter / max(1e-9, (ax2 - ax1) * (ay2 - ay1) + (bx2 - bx1) * (by2 - by1) - inter)

def nms(boxes, scores, iou_thr):
    keep = []
    idx = np.argsort(scores)[::-1]
    while len(idx):
        i = idx[0]
        keep.append(i)
        rest = []
        for j in idx[1:]:
            if iou(boxes[i], boxes[j]) < iou_thr:
                rest.append(j)
        idx = np.array(rest)
    return keep

def postprocess(out, r, left, top, orig_h, orig_w, conf_thr):
    pred = out[0].T  # 8400 x 84
    boxes_c, scores_c, cls_c = pred[:, :4], pred[:, 4:], pred[:, 4:]
    cls_ids = cls_c.argmax(axis=1)
    scores = scores_c[np.arange(len(scores_c)), cls_ids]
    mask = scores >= conf_thr
    dets = []
    for cx, cy, w, h, s, c in zip(boxes_c[mask, 0], boxes_c[mask, 1], boxes_c[mask, 2], boxes_c[mask, 3],
                                  scores[mask], cls_ids[mask]):
        x1 = (cx - w / 2 - left) / r
        y1 = (cy - h / 2 - top) / r
        x2 = (cx + w / 2 - left) / r
        y2 = (cy + h / 2 - top) / r
        dets.append([x1, y1, x2, y2, float(s), int(c)])
    # per-class NMS
    final = []
    for c in set(d[5] for d in dets):
        group = [d for d in dets if d[5] == c]
        keep = nms([d[:4] for d in group], [d[4] for d in group], NMS_IOU)
        final.extend(group[i] for i in keep)
    final.sort(key=lambda d: -d[4])
    return final

def annotate(img, dets, path, label_names):
    vis = img.copy()
    for x1, y1, x2, y2, s, c in dets:
        p1 = (int(max(0, x1)), int(max(0, y1)))
        p2 = (int(min(img.shape[1], x2)), int(min(img.shape[0], y2)))
        cv2.rectangle(vis, p1, p2, (0, 255, 0), 2)
        cv2.putText(vis, f"{label_names[c]} {s:.2f}", (p1[0], max(15, p1[1] - 4)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)
    ext = os.path.splitext(path)[1] or ".jpg"
    ok, buf = cv2.imencode(ext, vis)
    if ok:
        buf.tofile(path)

def main():
    # read pairs
    pairs, ir_vis = [], {}
    with open(CSV_PATH, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            pid = row["pair_id"]
            pairs.append(pid)
            ir_vis[pid] = (row["ir_path"], row["vis_path"])

    done = set()
    if os.path.exists(OUT_JSONL):
        with open(OUT_JSONL, encoding="utf-8") as f:
            for line in f:
                try:
                    d = json.loads(line)
                    done.add((d["pair"], d["method"]))
                except Exception:
                    pass

    sess = ort.InferenceSession(MODEL, providers=["CPUExecutionProvider"])
    so = sess.get_inputs()[0].name

    LABELS = ["person","bicycle","car","motorcycle","airplane","bus","train","truck","boat",
              "traffic light","fire hydrant","stop sign","parking meter","bench","bird","cat",
              "dog","horse","sheep","cow","elephant","bear","zebra","giraffe","backpack",
              "umbrella","handbag","tie","suitcase","frisbee","skis","snowboard","sports ball",
              "kite","baseball bat","baseball glove","skateboard","surfboard","tennis racket",
              "bottle","wine glass","cup","fork","knife","spoon","bowl","banana","apple",
              "sandwich","orange","broccoli","carrot","hot dog","pizza","donut","cake","chair",
              "couch","potted plant","bed","dining table","toilet","tv","laptop","mouse",
              "remote","keyboard","cell phone","microwave","oven","toaster","sink",
              "refrigerator","book","clock","vase","scissors","teddy bear","hair drier",
              "toothbrush"]

    fout = open(OUT_JSONL, "a", encoding="utf-8")
    n_done = 0
    for pid in pairs:
        for m in ORDER:
            if (pid, m) in done:
                continue
            path = get_path(m, pid, ir_vis)
            if not os.path.exists(path):
                print("MISSING", path, file=sys.stderr)
                continue
            img, blob, r, left, top = preprocess(path)
            out = sess.run(None, {so: blob})
            rec = {"pair": pid, "method": m, "shape": list(img.shape[:2])}
            dets_main = None
            for ct in CONF_THRESHOLDS:
                dets = postprocess(out[0], r, left, top, img.shape[0], img.shape[1], ct)
                n_person = sum(1 for d in dets if d[5] == COCO_PERSON)
                n_veh = sum(1 for d in dets if d[5] in COCO_VEHICLES)
                rec[f"ct{ct}"] = {"total": len(dets), "person": n_person, "vehicle": n_veh,
                                  "mean_conf": (float(np.mean([d[4] for d in dets])) if dets else 0.0)}
                if ct == MAIN_CONF:
                    dets_main = dets
            rec["classes"] = sorted(set(int(d[5]) for d in dets_main))
            rec["dets"] = [[float(round(d[0],1)), float(round(d[1],1)), float(round(d[2],1)), float(round(d[3],1)),
                            float(round(d[4],3)), int(d[5])] for d in dets_main]
            fout.write(json.dumps(rec) + "\n")
            fout.flush()
            ann_path = os.path.join(ANN_DIR, f"{pid}_{m}.jpg")
            annotate(img, dets_main, ann_path, LABELS)
            n_done += 1
            if n_done % 20 == 0:
                print(f"done {n_done} (at {pid}/{m})", flush=True)
    fout.close()
    print("ALL DONE", len(pairs) * len(ORDER))

if __name__ == "__main__":
    main()
