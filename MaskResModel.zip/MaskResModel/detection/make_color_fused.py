# -*- coding: utf-8 -*-
"""Reconstruct COLOR fused outputs for grayscale-output baselines via YCbCr merge
(fused luminance Y + CbCr from the visible image) — the standard way fusion
methods produce color results for downstream tasks. Saves to yolo/color_fused/."""
import csv, os
import numpy as np
import cv2

ROOT = r'C:\Users\zcwan\Desktop\多模态\IRVIS_Fusion_SCI'
HERE = os.path.dirname(os.path.abspath(__file__))
METHODS = {'DWT': 'DWT', 'GTF': 'GTF', 'DenseFuse': 'DenseFuse',
           'RFN-Nest': 'RFN_Nest', 'FusionGAN': 'FusionGAN', 'TarDAL': 'TarDAL'}

rows = list(csv.DictReader(open(os.path.join(ROOT, 'data', 'roadscene_test.csv'), encoding='utf-8')))
print('pairs:', len(rows))

for disp, dirname in METHODS.items():
    src = os.path.join(ROOT, 'baselines', dirname, 'roadscene_test', 'fused')
    dst = os.path.join(HERE, 'color_fused', disp)
    os.makedirs(dst, exist_ok=True)
    n = 0
    for r in rows:
        pid = r['pair_id']
        fy = os.path.join(src, pid + '.png')
        if not os.path.exists(fy):
            continue
        y = cv2.imdecode(np.fromfile(fy, dtype=np.uint8), cv2.IMREAD_GRAYSCALE)
        vis = cv2.imdecode(np.fromfile(r['vis_path'], dtype=np.uint8), cv2.IMREAD_COLOR)
        vis = cv2.resize(vis, (256, 256), interpolation=cv2.INTER_LINEAR)
        ycrcb = cv2.cvtColor(vis, cv2.COLOR_BGR2YCrCb)
        ycrcb[:, :, 0] = y
        color = cv2.cvtColor(ycrcb, cv2.COLOR_YCrCb2BGR)
        cv2.imencode('.png', color)[1].tofile(os.path.join(dst, pid + '.png'))
        n += 1
    print(disp, 'reconstructed', n)
print('done')
