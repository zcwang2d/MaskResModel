# -*- coding: utf-8 -*-
"""Aggregate detection results: count stats + pseudo-GT recall (union of IR&VIS dets).
All boxes are normalized to [0,1] coordinates before IoU matching, because IR (512x640),
VIS (~1000x1400) and fused (256x256) live in different pixel frames; RoadScene pairs
are aligned up to scale."""
import json
import numpy as np

ORDER = ['IR', 'VIS', 'DWT', 'GTF', 'DenseFuse', 'RFN-Nest', 'FusionGAN', 'TarDAL', 'Ours']
recs = {}
for line in open('detections.jsonl', encoding='utf-8'):
    r = json.loads(line)
    recs[(r['pair'], r['method'])] = r
pairs = sorted(set(r['pair'] for r in recs.values()))

def norm(dets, shape):
    h, w = shape
    return [[d[0]/w, d[1]/h, d[2]/w, d[3]/h, d[4], d[5]] for d in dets]

def iou(a, b):
    x1, y1 = max(a[0], b[0]), max(a[1], b[1])
    x2, y2 = min(a[2], b[2]), min(a[3], b[3])
    iw, ih = max(0, x2 - x1), max(0, y2 - y1)
    inter = iw * ih
    return inter / max(1e-9, (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - inter)

def match(gt, dets, thr=0.5):
    matched = 0
    for cls in set(g[5] for g in gt):
        gcls = [g for g in gt if g[5] == cls]
        dcls = [d for d in dets if d[5] == cls]
        used = set()
        for g in sorted(gcls, key=lambda g: -g[4]):
            best, bi = thr, -1
            for i, d in enumerate(dcls):
                if i in used: continue
                v = iou(g, d)
                if v >= best:
                    best, bi = v, i
            if bi >= 0:
                used.add(bi)
                matched += 1
    return matched

nd = {}
for k, r in recs.items():
    nd[k] = norm(r['dets'], r['shape'])

summary = {}
pseudo_gt_sizes = []
for m in ORDER:
    tot_list, per_list, veh_list, rate_list, conf_list, rec_list = [], [], [], [], [], []
    for p in pairs:
        r = recs[(p, m)]
        c = r['ct0.25']
        tot_list.append(c['total']); per_list.append(c['person']); veh_list.append(c['vehicle'])
        rate_list.append(1 if c['total'] > 0 else 0)
        if c['total'] > 0:
            conf_list.append(c['mean_conf'])
        gt = nd[(p, 'IR')] + nd[(p, 'VIS')]
        if m == 'IR':
            pseudo_gt_sizes.append(len(gt))
        if gt:
            mtc = match(gt, nd[(p, m)])
            rec_list.append(mtc / len(gt))
    summary[m] = {
        'avg_total': float(np.mean(tot_list)),
        'avg_person': float(np.mean(per_list)),
        'avg_vehicle': float(np.mean(veh_list)),
        'det_rate': float(np.mean(rate_list)),
        'mean_conf': float(np.mean(conf_list)) if conf_list else 0.0,
        'pseudo_recall': float(np.mean(rec_list)),
    }
    print(f"{m:<10} tot={summary[m]['avg_total']:5.2f} per={summary[m]['avg_person']:5.2f} "
          f"veh={summary[m]['avg_vehicle']:5.2f} rate={summary[m]['det_rate']:.2f} "
          f"conf={summary[m]['mean_conf']:.3f} recall={summary[m]['pseudo_recall']:.3f}")

json.dump(summary, open('summary.json', 'w', encoding='utf-8'), indent=1)
print('pairs:', len(pairs), 'avg pseudo-GT size:', float(np.mean(pseudo_gt_sizes)))

cands = []
for p in pairs:
    gt = nd[(p, 'IR')] + nd[(p, 'VIS')]
    if len(gt) < 2:
        continue
    ro = match(gt, nd[(p, 'Ours')])
    scores = {m2: match(gt, nd[(p, m2)]) for m2 in ORDER}
    base = max(scores['TarDAL'], scores['DenseFuse'], scores['RFN-Nest'], scores['FusionGAN'])
    cands.append({'pair': p, 'gt': len(gt), 'ours': ro, 'base_best': base,
                  'adv': ro - base, 'scores': scores})
cands.sort(key=lambda c: (-c['adv'], -c['gt']))
json.dump(cands, open('scenes.json', 'w', encoding='utf-8'), indent=1)
for c in cands[:10]:
    print(c['pair'], 'gt=%d ours=%d basebest=%d' % (c['gt'], c['ours'], c['base_best']), c['scores'])
